"""
AI Act QMS - Control Charts for AI Model Monitoring

Implements Statistical Process Control (SPC) charts for AI metrics:
- I-MR (Individual & Moving Range) Charts for continuous metrics
- X-bar / R Charts for subgroup data
- p-Charts for proportions (error rates, bias metrics)
- EWMA (Exponentially Weighted Moving Average) for drift

Author: AI Act QMS Skill
Version: 1.0
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import List, Tuple, Dict, Optional
import warnings

warnings.filterwarnings('ignore')


class AIControlCharts:
    """
    Statistical Process Control charts for AI model monitoring.
    
    Implements Western Electric Rules for out-of-control detection.
    """
    
    def __init__(self):
        self.western_electric_violations = []
    
    def i_mr_chart(self,
                   data: np.ndarray,
                   metric_name: str = "Metric",
                   target: Optional[float] = None,
                   spec_limits: Optional[Tuple[float, float]] = None,
                   save_path: Optional[str] = None) -> Dict:
        """
        Individual (I) and Moving Range (MR) Chart.
        
        Use for: Individual measurements over time (e.g., daily accuracy, weekly precision)
        
        Args:
            data: Array of individual measurements
            metric_name: Name of the metric (for labeling)
            target: Target value (optional)
            spec_limits: (LSL, USL) specification limits
            save_path: Path to save plot (optional)
            
        Returns:
            Dictionary with control limits and violations
        """
        # Calculate I-Chart statistics
        x_mean = np.mean(data)
        
        # Moving Range
        mr = np.abs(np.diff(data))
        mr_mean = np.mean(mr)
        
        # Control limits for I-Chart
        # d2 for n=2 (moving range) = 1.128
        d2 = 1.128
        ucl_i = x_mean + 2.66 * (mr_mean / d2)
        lcl_i = x_mean - 2.66 * (mr_mean / d2)
        
        # Control limits for MR-Chart
        # D4 for n=2 = 3.267, D3 for n=2 = 0
        ucl_mr = 3.267 * mr_mean
        lcl_mr = 0  # Always 0 for n=2
        
        # Detect violations (Western Electric Rules)
        violations = self._check_western_electric_rules(data, x_mean, ucl_i, lcl_i)
        
        # Plot
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
        
        # I-Chart
        ax1.plot(data, 'bo-', label='Individual Values', markersize=4)
        ax1.axhline(x_mean, color='green', linestyle='--', label=f'Center Line ({x_mean:.4f})')
        ax1.axhline(ucl_i, color='red', linestyle='--', label=f'UCL ({ucl_i:.4f})')
        ax1.axhline(lcl_i, color='red', linestyle='--', label=f'LCL ({lcl_i:.4f})')
        
        if target is not None:
            ax1.axhline(target, color='blue', linestyle=':', linewidth=2, label=f'Target ({target:.4f})')
        
        if spec_limits:
            lsl, usl = spec_limits
            ax1.axhline(usl, color='orange', linestyle=':', linewidth=2, label=f'USL ({usl:.4f})')
            ax1.axhline(lsl, color='orange', linestyle=':', linewidth=2, label=f'LSL ({lsl:.4f})')
        
        # Mark violations
        for idx, violation_type in violations.items():
            ax1.plot(idx, data[idx], 'rx', markersize=10, markeredgewidth=2)
            ax1.annotate(violation_type, xy=(idx, data[idx]), 
                        xytext=(5, 5), textcoords='offset points', fontsize=8, color='red')
        
        ax1.set_xlabel('Sample Number')
        ax1.set_ylabel(metric_name)
        ax1.set_title(f'I-Chart: {metric_name}')
        ax1.legend(loc='best')
        ax1.grid(True, alpha=0.3)
        
        # MR-Chart
        ax2.plot(mr, 'go-', label='Moving Range', markersize=4)
        ax2.axhline(mr_mean, color='green', linestyle='--', label=f'MR Mean ({mr_mean:.4f})')
        ax2.axhline(ucl_mr, color='red', linestyle='--', label=f'UCL ({ucl_mr:.4f})')
        ax2.axhline(lcl_mr, color='red', linestyle='--', label=f'LCL ({lcl_mr:.4f})')
        
        ax2.set_xlabel('Sample Number')
        ax2.set_ylabel('Moving Range')
        ax2.set_title('MR-Chart: Variability')
        ax2.legend(loc='best')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Chart saved to: {save_path}")
        
        plt.show()
        
        # Return results
        result = {
            'metric_name': metric_name,
            'center_line': x_mean,
            'ucl': ucl_i,
            'lcl': lcl_i,
            'mr_mean': mr_mean,
            'ucl_mr': ucl_mr,
            'violations': violations,
            'in_control': len(violations) == 0,
            'process_sigma': mr_mean / d2
        }
        
        return result
    
    def p_chart(self,
                data: Dict[str, List[float]],
                metric_name: str = "Error Rate",
                threshold: float = 0.05,
                save_path: Optional[str] = None) -> Dict:
        """
        p-Chart for proportions (e.g., error rates by subgroup).
        
        Use for: Monitoring error rates, bias metrics across groups
        
        Args:
            data: Dictionary mapping group names to lists of proportions
            metric_name: Name of the metric
            threshold: Target threshold
            save_path: Path to save plot
            
        Returns:
            Dictionary with control limits per group
        """
        fig, ax = plt.subplots(figsize=(14, 6))
        
        results = {}
        colors = plt.cm.Set2(np.linspace(0, 1, len(data)))
        
        for idx, (group_name, proportions) in enumerate(data.items()):
            p_bar = np.mean(proportions)
            n = len(proportions)
            
            # Assume average sample size for simplicity (or pass as parameter)
            n_avg = 100  # This should be actual sample size
            
            # Control limits
            # Note: For varying sample sizes, calculate per point
            ucl = p_bar + 3 * np.sqrt(p_bar * (1 - p_bar) / n_avg)
            lcl = max(0, p_bar - 3 * np.sqrt(p_bar * (1 - p_bar) / n_avg))
            
            # Plot
            x_positions = np.arange(len(proportions)) + idx * 0.2
            ax.plot(x_positions, proportions, 'o-', 
                   color=colors[idx], label=group_name, markersize=4, alpha=0.7)
            ax.axhline(p_bar, color=colors[idx], linestyle='--', alpha=0.5)
            
            # Store results
            results[group_name] = {
                'mean': p_bar,
                'ucl': ucl,
                'lcl': lcl,
                'in_control': all(lcl <= p <= ucl for p in proportions)
            }
        
        # Add threshold line
        ax.axhline(threshold, color='red', linestyle=':', linewidth=2, 
                  label=f'Threshold ({threshold:.2%})')
        
        ax.set_xlabel('Sample Number')
        ax.set_ylabel(metric_name)
        ax.set_title(f'p-Chart: {metric_name} by Group')
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Chart saved to: {save_path}")
        
        plt.show()
        
        return results
    
    def ewma_chart(self,
                   data: np.ndarray,
                   lambda_param: float = 0.2,
                   control_limit: float = 0.25,
                   metric_name: str = "PSI",
                   save_path: Optional[str] = None) -> Dict:
        """
        EWMA (Exponentially Weighted Moving Average) Chart for drift detection.
        
        Use for: Early drift detection (more sensitive than I-chart)
        
        Args:
            data: Array of measurements (e.g., PSI values)
            lambda_param: Weight for recent observations (0 < λ ≤ 1)
                         λ=0.2 recommended for drift detection
            control_limit: Threshold for drift (e.g., PSI > 0.25)
            metric_name: Name of the metric
            save_path: Path to save plot
            
        Returns:
            Dictionary with EWMA values and violations
        """
        # Calculate EWMA
        ewma = np.zeros(len(data))
        ewma[0] = data[0]
        
        for i in range(1, len(data)):
            ewma[i] = lambda_param * data[i] + (1 - lambda_param) * ewma[i-1]
        
        # Calculate control limits
        sigma = np.std(data)
        L = 3  # 3-sigma limits (standard)
        
        ucl = np.zeros(len(data))
        lcl = np.zeros(len(data))
        
        for i in range(len(data)):
            factor = np.sqrt(lambda_param / (2 - lambda_param) * 
                           (1 - (1 - lambda_param)**(2*(i+1))))
            ucl[i] = data.mean() + L * sigma * factor
            lcl[i] = max(0, data.mean() - L * sigma * factor)
        
        # Detect violations
        violations = {}
        for i in range(len(ewma)):
            if ewma[i] > control_limit:
                violations[i] = f"Above threshold ({control_limit})"
        
        # Plot
        fig, ax = plt.subplots(figsize=(12, 6))
        
        ax.plot(data, 'b.', label='Individual Values', alpha=0.5, markersize=6)
        ax.plot(ewma, 'r-', label=f'EWMA (λ={lambda_param})', linewidth=2)
        ax.axhline(control_limit, color='orange', linestyle='--', linewidth=2,
                  label=f'Threshold ({control_limit})')
        ax.plot(ucl, 'g--', label='UCL', alpha=0.7)
        ax.plot(lcl, 'g--', label='LCL', alpha=0.7)
        
        # Mark violations
        for idx in violations.keys():
            ax.plot(idx, ewma[idx], 'rx', markersize=12, markeredgewidth=2)
            ax.annotate('DRIFT!', xy=(idx, ewma[idx]), 
                       xytext=(5, 5), textcoords='offset points', 
                       fontsize=10, color='red', weight='bold')
        
        ax.set_xlabel('Time Period')
        ax.set_ylabel(metric_name)
        ax.set_title(f'EWMA Chart: {metric_name} Drift Detection')
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Chart saved to: {save_path}")
        
        plt.show()
        
        result = {
            'metric_name': metric_name,
            'ewma': ewma,
            'violations': violations,
            'drift_detected': len(violations) > 0,
            'first_drift_at': min(violations.keys()) if violations else None
        }
        
        return result
    
    def _check_western_electric_rules(self,
                                      data: np.ndarray,
                                      center: float,
                                      ucl: float,
                                      lcl: float) -> Dict[int, str]:
        """
        Check for violations of Western Electric Rules.
        
        Rules:
        1. One point beyond 3σ
        2. Two out of three consecutive points beyond 2σ
        3. Four out of five consecutive points beyond 1σ
        4. Eight consecutive points on same side of center
        
        Returns:
            Dictionary mapping index to violation type
        """
        violations = {}
        n = len(data)
        
        sigma = (ucl - center) / 3
        
        # Rule 1: One point beyond 3σ
        for i in range(n):
            if data[i] > ucl or data[i] < lcl:
                violations[i] = "Rule 1: Beyond 3σ"
        
        # Rule 2: Two out of three consecutive beyond 2σ
        for i in range(n - 2):
            window = data[i:i+3]
            beyond_2sigma = sum((w > center + 2*sigma) or (w < center - 2*sigma) 
                               for w in window)
            if beyond_2sigma >= 2:
                for j in range(i, i+3):
                    if j not in violations:
                        violations[j] = "Rule 2: 2/3 beyond 2σ"
        
        # Rule 3: Four out of five consecutive beyond 1σ
        for i in range(n - 4):
            window = data[i:i+5]
            beyond_1sigma = sum((w > center + sigma) or (w < center - sigma) 
                               for w in window)
            if beyond_1sigma >= 4:
                for j in range(i, i+5):
                    if j not in violations:
                        violations[j] = "Rule 3: 4/5 beyond 1σ"
        
        # Rule 4: Eight consecutive on same side
        for i in range(n - 7):
            window = data[i:i+8]
            all_above = all(w > center for w in window)
            all_below = all(w < center for w in window)
            if all_above or all_below:
                for j in range(i, i+8):
                    if j not in violations:
                        violations[j] = "Rule 4: 8 consecutive same side"
        
        return violations


# Example usage
if __name__ == "__main__":
    print("=" * 80)
    print("AI ACT QMS - CONTROL CHARTS FOR AI MODEL MONITORING")
    print("=" * 80)
    
    # Initialize
    charts = AIControlCharts()
    
    # 1. I-MR Chart for Accuracy
    print("\n1. I-MR CHART: MODEL ACCURACY")
    print("-" * 80)
    
    np.random.seed(42)
    # Simulate accuracy data with gradual drift
    baseline_accuracy = 0.92
    drift_rate = -0.002
    noise = 0.01
    
    accuracy_data = []
    for i in range(30):
        drift = drift_rate * i
        acc = baseline_accuracy + drift + np.random.normal(0, noise)
        accuracy_data.append(acc)
    
    accuracy_data = np.array(accuracy_data)
    
    result_imr = charts.i_mr_chart(
        data=accuracy_data,
        metric_name="Model Accuracy",
        target=0.92,
        spec_limits=(0.85, 1.0),
        save_path='/tmp/accuracy_imr_chart.png'
    )
    
    print(f"Center Line: {result_imr['center_line']:.4f}")
    print(f"UCL: {result_imr['ucl']:.4f}")
    print(f"LCL: {result_imr['lcl']:.4f}")
    print(f"In Control: {result_imr['in_control']}")
    
    if result_imr['violations']:
        print(f"\n⚠️  OUT OF CONTROL: {len(result_imr['violations'])} violations detected")
        for idx, rule in result_imr['violations'].items():
            print(f"  Point {idx}: {rule}")
    else:
        print("\n✅ Process in statistical control")
    
    # 2. p-Chart for Error Rates by Gender
    print("\n\n2. p-CHART: ERROR RATES BY GENDER")
    print("-" * 80)
    
    # Simulate error rates with bias
    male_error_rates = np.random.beta(2, 25, 20)  # ~7% error rate
    female_error_rates = np.random.beta(3, 20, 20)  # ~12% error rate (bias!)
    
    error_data = {
        'Male': male_error_rates.tolist(),
        'Female': female_error_rates.tolist()
    }
    
    result_p = charts.p_chart(
        data=error_data,
        metric_name="Error Rate",
        threshold=0.10,
        save_path='/tmp/error_rate_pchart.png'
    )
    
    for group, stats in result_p.items():
        print(f"\n{group}:")
        print(f"  Mean Error Rate: {stats['mean']:.2%}")
        print(f"  UCL: {stats['ucl']:.2%}")
        print(f"  In Control: {stats['in_control']}")
    
    # Check for bias
    male_mean = result_p['Male']['mean']
    female_mean = result_p['Female']['mean']
    gap = abs(male_mean - female_mean)
    
    if gap > 0.05:
        print(f"\n❌ BIAS DETECTED: Error rate gap = {gap:.2%} (> 5% threshold)")
        print("   → Trigger Bias Incident Response SOP (SOP-AI-002)")
    else:
        print(f"\n✅ No significant bias: Error rate gap = {gap:.2%}")
    
    # 3. EWMA Chart for PSI Drift Detection
    print("\n\n3. EWMA CHART: PSI DRIFT DETECTION")
    print("-" * 80)
    
    # Simulate PSI values with increasing drift
    psi_baseline = 0.05
    psi_drift_rate = 0.03
    
    psi_data = []
    for i in range(20):
        drift = psi_drift_rate * (i / 10) if i > 10 else 0
        psi = psi_baseline + drift + np.random.normal(0, 0.01)
        psi = max(0, psi)  # PSI can't be negative
        psi_data.append(psi)
    
    psi_data = np.array(psi_data)
    
    result_ewma = charts.ewma_chart(
        data=psi_data,
        lambda_param=0.2,
        control_limit=0.25,
        metric_name="PSI (Population Stability Index)",
        save_path='/tmp/psi_ewma_chart.png'
    )
    
    print(f"Drift Detected: {result_ewma['drift_detected']}")
    
    if result_ewma['drift_detected']:
        print(f"First Drift at: Period {result_ewma['first_drift_at']}")
        print("\n🚨 DRIFT ALERT:")
        print("   → Trigger Model Drift Response SOP (SOP-AI-001)")
        print("   → Escalate to Model Risk Manager (48h mitigation plan)")
        print("   → Consider accelerated retraining")
    else:
        print("\n✅ No significant drift detected")
    
    print("\n" + "=" * 80)
    print("END OF CONTROL CHARTS REPORT")
    print("=" * 80)
    
    print("\n\n📋 AI ACT ART. 72 COMPLIANCE SUMMARY")
    print("-" * 80)
    print("Post-Market Monitoring Plan execution:")
    print(f"  ✅ Accuracy monitoring: {'In control' if result_imr['in_control'] else 'OUT OF CONTROL'}")
    print(f"  {'✅' if gap <= 0.05 else '❌'} Bias monitoring: {'Within threshold' if gap <= 0.05 else 'BIAS DETECTED'}")
    print(f"  {'✅' if not result_ewma['drift_detected'] else '🚨'} Drift monitoring: {'No drift' if not result_ewma['drift_detected'] else 'DRIFT DETECTED'}")
    print("\nAll monitoring as per Art. 72 requirements documented in Evidence Log.")
