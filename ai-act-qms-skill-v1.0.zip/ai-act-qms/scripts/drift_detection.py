"""
AI Act QMS - Drift Detection Module

Implements various drift detection methods for AI model monitoring:
- Population Stability Index (PSI) for feature drift
- Kolmogorov-Smirnov (KS) Test for distribution changes
- Prediction Drift Detection
- Data Quality Drift

Author: AI Act QMS Skill
Version: 1.0
"""

import numpy as np
import pandas as pd
from scipy import stats
from typing import Dict, Tuple, List
import warnings

warnings.filterwarnings('ignore')


class DriftDetector:
    """
    Comprehensive drift detection for AI models.
    
    Supports:
    - Feature drift (PSI, KS-Test)
    - Prediction drift
    - Data quality drift
    """
    
    def __init__(self, baseline_data: pd.DataFrame, target_col: str = None):
        """
        Initialize drift detector with baseline data.
        
        Args:
            baseline_data: Training or reference dataset
            target_col: Name of target column (if available)
        """
        self.baseline = baseline_data
        self.target_col = target_col
        
    def calculate_psi(self, 
                     production_data: pd.DataFrame, 
                     feature: str, 
                     buckets: int = 10) -> Tuple[float, str]:
        """
        Calculate Population Stability Index (PSI) for a feature.
        
        PSI < 0.1: No significant shift
        PSI 0.1-0.25: Moderate shift, investigate
        PSI > 0.25: Significant shift, retrain recommended
        
        Args:
            production_data: Current production data
            feature: Feature name to analyze
            buckets: Number of buckets for binning
            
        Returns:
            Tuple of (PSI value, interpretation)
        """
        baseline_feature = self.baseline[feature].dropna()
        production_feature = production_data[feature].dropna()
        
        # Create bins based on baseline quantiles
        breakpoints = np.percentile(baseline_feature, 
                                   np.linspace(0, 100, buckets + 1))
        breakpoints = np.unique(breakpoints)  # Remove duplicates
        
        # Calculate percentages in each bucket
        baseline_percents = np.histogram(baseline_feature, bins=breakpoints)[0] / len(baseline_feature)
        production_percents = np.histogram(production_feature, bins=breakpoints)[0] / len(production_feature)
        
        # Add small epsilon to avoid log(0)
        epsilon = 1e-10
        baseline_percents = baseline_percents + epsilon
        production_percents = production_percents + epsilon
        
        # Calculate PSI
        psi_values = (production_percents - baseline_percents) * \
                     np.log(production_percents / baseline_percents)
        psi = np.sum(psi_values)
        
        # Interpretation
        if psi < 0.1:
            interpretation = "✅ No significant drift"
        elif psi < 0.25:
            interpretation = "⚠️  Moderate drift - investigate"
        else:
            interpretation = "❌ Significant drift - retrain recommended"
            
        return psi, interpretation
    
    def calculate_psi_all_features(self, 
                                   production_data: pd.DataFrame,
                                   buckets: int = 10) -> pd.DataFrame:
        """
        Calculate PSI for all numeric features.
        
        Returns:
            DataFrame with PSI values and interpretations
        """
        results = []
        
        numeric_cols = self.baseline.select_dtypes(include=[np.number]).columns
        if self.target_col and self.target_col in numeric_cols:
            numeric_cols = numeric_cols.drop(self.target_col)
        
        for feature in numeric_cols:
            try:
                psi, interpretation = self.calculate_psi(production_data, feature, buckets)
                results.append({
                    'Feature': feature,
                    'PSI': round(psi, 4),
                    'Status': interpretation,
                    'Priority': 'High' if psi > 0.25 else 'Medium' if psi > 0.1 else 'Low'
                })
            except Exception as e:
                results.append({
                    'Feature': feature,
                    'PSI': None,
                    'Status': f'Error: {str(e)}',
                    'Priority': 'Review'
                })
        
        return pd.DataFrame(results).sort_values('PSI', ascending=False)
    
    def ks_test(self, 
                production_data: pd.DataFrame, 
                feature: str) -> Tuple[float, float, str]:
        """
        Kolmogorov-Smirnov Test for distribution comparison.
        
        Tests if production data comes from same distribution as baseline.
        
        Args:
            production_data: Current production data
            feature: Feature name to test
            
        Returns:
            Tuple of (KS statistic, p-value, interpretation)
        """
        baseline_feature = self.baseline[feature].dropna()
        production_feature = production_data[feature].dropna()
        
        # Perform KS test
        ks_stat, p_value = stats.ks_2samp(baseline_feature, production_feature)
        
        # Interpretation (using alpha = 0.05)
        if p_value > 0.05:
            interpretation = f"✅ Same distribution (p={p_value:.4f})"
        elif ks_stat < 0.1:
            interpretation = f"⚠️  Small difference (KS={ks_stat:.4f}, p={p_value:.4f})"
        else:
            interpretation = f"❌ Significant difference (KS={ks_stat:.4f}, p={p_value:.4f})"
        
        return ks_stat, p_value, interpretation
    
    def prediction_drift(self,
                        baseline_predictions: np.ndarray,
                        production_predictions: np.ndarray) -> Dict[str, any]:
        """
        Detect drift in model predictions.
        
        Compares distribution of predictions between baseline and production.
        
        Args:
            baseline_predictions: Predictions on baseline data
            production_predictions: Current predictions
            
        Returns:
            Dictionary with drift metrics
        """
        # Statistical tests
        ks_stat, p_value = stats.ks_2samp(baseline_predictions, production_predictions)
        
        # Descriptive statistics
        baseline_mean = np.mean(baseline_predictions)
        production_mean = np.mean(production_predictions)
        mean_shift = (production_mean - baseline_mean) / baseline_mean * 100
        
        baseline_std = np.std(baseline_predictions)
        production_std = np.std(production_predictions)
        std_change = (production_std - baseline_std) / baseline_std * 100
        
        # Interpretation
        if abs(mean_shift) > 10:
            mean_status = f"❌ Mean shifted by {mean_shift:.2f}%"
        elif abs(mean_shift) > 5:
            mean_status = f"⚠️  Mean shifted by {mean_shift:.2f}%"
        else:
            mean_status = f"✅ Mean stable ({mean_shift:.2f}%)"
        
        if abs(std_change) > 20:
            std_status = f"❌ Std Dev changed by {std_change:.2f}%"
        elif abs(std_change) > 10:
            std_status = f"⚠️  Std Dev changed by {std_change:.2f}%"
        else:
            std_status = f"✅ Std Dev stable ({std_change:.2f}%)"
        
        return {
            'KS_Statistic': round(ks_stat, 4),
            'KS_P_Value': round(p_value, 4),
            'Baseline_Mean': round(baseline_mean, 4),
            'Production_Mean': round(production_mean, 4),
            'Mean_Shift_%': round(mean_shift, 2),
            'Mean_Status': mean_status,
            'Baseline_Std': round(baseline_std, 4),
            'Production_Std': round(production_std, 4),
            'Std_Change_%': round(std_change, 2),
            'Std_Status': std_status,
            'Overall_Status': 'Drift Detected' if p_value < 0.05 else 'No Drift'
        }
    
    def data_quality_drift(self, 
                          production_data: pd.DataFrame) -> pd.DataFrame:
        """
        Detect drift in data quality metrics.
        
        Compares:
        - Missing value rates
        - Outlier rates
        - Cardinality changes (for categorical)
        
        Args:
            production_data: Current production data
            
        Returns:
            DataFrame with data quality drift metrics
        """
        results = []
        
        for col in self.baseline.columns:
            if col == self.target_col:
                continue
                
            baseline_missing = self.baseline[col].isna().mean() * 100
            production_missing = production_data[col].isna().mean() * 100
            missing_change = production_missing - baseline_missing
            
            # Check if categorical
            if self.baseline[col].dtype == 'object' or len(self.baseline[col].unique()) < 20:
                baseline_cardinality = self.baseline[col].nunique()
                production_cardinality = production_data[col].nunique()
                cardinality_change = production_cardinality - baseline_cardinality
                
                results.append({
                    'Feature': col,
                    'Type': 'Categorical',
                    'Baseline_Missing_%': round(baseline_missing, 2),
                    'Production_Missing_%': round(production_missing, 2),
                    'Missing_Change': round(missing_change, 2),
                    'Baseline_Cardinality': baseline_cardinality,
                    'Production_Cardinality': production_cardinality,
                    'Cardinality_Change': cardinality_change,
                    'Status': '❌ Issue' if abs(missing_change) > 5 or abs(cardinality_change) > 0 
                             else '✅ OK'
                })
            else:
                # Numeric - check outliers (IQR method)
                q1_baseline = self.baseline[col].quantile(0.25)
                q3_baseline = self.baseline[col].quantile(0.75)
                iqr_baseline = q3_baseline - q1_baseline
                outliers_baseline = ((self.baseline[col] < (q1_baseline - 1.5 * iqr_baseline)) | 
                                    (self.baseline[col] > (q3_baseline + 1.5 * iqr_baseline))).mean() * 100
                
                q1_production = production_data[col].quantile(0.25)
                q3_production = production_data[col].quantile(0.75)
                iqr_production = q3_production - q1_production
                outliers_production = ((production_data[col] < (q1_production - 1.5 * iqr_production)) | 
                                      (production_data[col] > (q3_production + 1.5 * iqr_production))).mean() * 100
                
                outlier_change = outliers_production - outliers_baseline
                
                results.append({
                    'Feature': col,
                    'Type': 'Numeric',
                    'Baseline_Missing_%': round(baseline_missing, 2),
                    'Production_Missing_%': round(production_missing, 2),
                    'Missing_Change': round(missing_change, 2),
                    'Baseline_Outliers_%': round(outliers_baseline, 2),
                    'Production_Outliers_%': round(outliers_production, 2),
                    'Outlier_Change': round(outlier_change, 2),
                    'Status': '❌ Issue' if abs(missing_change) > 5 or abs(outlier_change) > 5 
                             else '✅ OK'
                })
        
        return pd.DataFrame(results)


# Example usage and testing
if __name__ == "__main__":
    # Generate synthetic data for demonstration
    np.random.seed(42)
    
    # Baseline data (Training)
    n_baseline = 1000
    baseline = pd.DataFrame({
        'age': np.random.normal(45, 12, n_baseline),
        'income': np.random.lognormal(10.5, 0.5, n_baseline),
        'credit_score': np.random.normal(700, 50, n_baseline),
        'loan_amount': np.random.normal(50000, 15000, n_baseline),
        'category': np.random.choice(['A', 'B', 'C'], n_baseline),
        'target': np.random.binomial(1, 0.3, n_baseline)
    })
    
    # Production data WITH drift
    n_production = 500
    production = pd.DataFrame({
        'age': np.random.normal(48, 13, n_production),  # Slight mean shift
        'income': np.random.lognormal(10.7, 0.6, n_production),  # Drift
        'credit_score': np.random.normal(690, 55, n_production),  # Drift
        'loan_amount': np.random.normal(52000, 16000, n_production),  # Slight shift
        'category': np.random.choice(['A', 'B', 'C', 'D'], n_production),  # New category
        'target': np.random.binomial(1, 0.35, n_production)
    })
    
    # Initialize detector
    detector = DriftDetector(baseline_data=baseline, target_col='target')
    
    print("=" * 80)
    print("AI ACT QMS - DRIFT DETECTION REPORT")
    print("=" * 80)
    
    # 1. PSI for all features
    print("\n1. POPULATION STABILITY INDEX (PSI)")
    print("-" * 80)
    psi_results = detector.calculate_psi_all_features(production)
    print(psi_results.to_string(index=False))
    
    # 2. KS Test for key features
    print("\n\n2. KOLMOGOROV-SMIRNOV TEST")
    print("-" * 80)
    for feature in ['age', 'income', 'credit_score']:
        ks_stat, p_value, interpretation = detector.ks_test(production, feature)
        print(f"{feature:15s} | KS={ks_stat:.4f} | {interpretation}")
    
    # 3. Prediction Drift
    print("\n\n3. PREDICTION DRIFT ANALYSIS")
    print("-" * 80)
    baseline_preds = baseline['target']
    production_preds = production['target']
    pred_drift = detector.prediction_drift(baseline_preds, production_preds)
    for key, value in pred_drift.items():
        print(f"{key:20s}: {value}")
    
    # 4. Data Quality Drift
    print("\n\n4. DATA QUALITY DRIFT")
    print("-" * 80)
    quality_drift = detector.data_quality_drift(production)
    print(quality_drift.to_string(index=False))
    
    print("\n" + "=" * 80)
    print("END OF DRIFT DETECTION REPORT")
    print("=" * 80)
    
    # Art. 72 Compliance Summary
    print("\n\n📋 AI ACT ART. 72 COMPLIANCE SUMMARY")
    print("-" * 80)
    
    high_priority = psi_results[psi_results['Priority'] == 'High']
    if len(high_priority) > 0:
        print("⚠️  WARNING: High priority drift detected!")
        print(f"\nFeatures requiring immediate attention:")
        for _, row in high_priority.iterrows():
            print(f"  • {row['Feature']}: PSI = {row['PSI']}")
        print("\nRecommended Actions:")
        print("  1. Perform root cause analysis within 48 hours")
        print("  2. Escalate to Model Risk Manager")
        print("  3. Consider accelerated retraining")
        print("  4. Document incident in Evidence Log")
    else:
        print("✅ All features within acceptable drift thresholds")
        print("   Continue regular monitoring as per Monitoring Plan")
