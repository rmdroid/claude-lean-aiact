"""
AI Act QMS - FMEA Calculator for AI Risks

Calculates Risk Priority Numbers (RPN) and prioritizes AI-specific risks
for EU AI Act Art. 9 compliance.

RPN = Severity × Occurrence × Detection

Author: AI Act QMS Skill
Version: 1.0
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Tuple
import matplotlib.pyplot as plt
import seaborn as sns


class AIFMEACalculator:
    """
    FMEA (Failure Mode and Effects Analysis) Calculator for AI systems.
    
    Supports:
    - RPN calculation
    - Risk prioritization
    - Mitigation tracking
    - Pareto analysis
    """
    
    def __init__(self):
        self.severity_scale = {
            'Negligible (1-3)': 'Minor impact, no fundamental rights affected',
            'Marginal (4-6)': 'Moderate impact, some user inconvenience',
            'Critical (7-8)': 'Severe impact, potential fundamental rights violation',
            'Catastrophic (9-10)': 'Severe fundamental rights violation'
        }
        
        self.occurrence_scale = {
            'Remote (1-2)': 'Very unlikely, <1% probability',
            'Low (3-4)': 'Unlikely, 1-5% probability',
            'Moderate (5-6)': 'Occasional, 5-20% probability',
            'High (7-8)': 'Likely, 20-50% probability',
            'Very High (9-10)': 'Very likely, >50% probability'
        }
        
        self.detection_scale = {
            'Very High (1-2)': 'Always detected, automated monitoring',
            'High (3-4)': 'Usually detected, regular reviews',
            'Moderate (5-6)': 'Sometimes detected, sampling',
            'Low (7-8)': 'Rarely detected, only when escalated',
            'Very Low (9-10)': 'Almost never detected before impact'
        }
    
    def calculate_rpn(self,
                     severity: int,
                     occurrence: int,
                     detection: int) -> int:
        """
        Calculate Risk Priority Number.
        
        Args:
            severity: 1-10 (impact on users/fundamental rights)
            occurrence: 1-10 (likelihood of failure)
            detection: 1-10 (difficulty of detection)
            
        Returns:
            RPN (1-1000)
        """
        if not all(1 <= x <= 10 for x in [severity, occurrence, detection]):
            raise ValueError("All ratings must be between 1 and 10")
        
        return severity * occurrence * detection
    
    def classify_priority(self, rpn: int) -> Tuple[str, str]:
        """
        Classify risk priority based on RPN.
        
        Returns:
            (priority_level, action_required)
        """
        if rpn > 400:
            return 'Critical', 'Immediate action required'
        elif rpn >= 200:
            return 'High', 'Action within 3 months'
        elif rpn >= 100:
            return 'Medium', 'Action within 6 months'
        else:
            return 'Low', 'Monitor and accept'
    
    def create_fmea_table(self,
                         failure_modes: List[Dict]) -> pd.DataFrame:
        """
        Create FMEA table from failure modes.
        
        Args:
            failure_modes: List of dicts with keys:
                - failure_mode: str
                - effect: str
                - severity: int (1-10)
                - causes: str
                - occurrence: int (1-10)
                - current_controls: str
                - detection: int (1-10)
                - mitigation: str (optional)
                - owner: str (optional)
                
        Returns:
            DataFrame with FMEA table
        """
        fmea_data = []
        
        for fm in failure_modes:
            rpn = self.calculate_rpn(
                fm['severity'],
                fm['occurrence'],
                fm['detection']
            )
            
            priority, action = self.classify_priority(rpn)
            
            row = {
                'Failure Mode': fm['failure_mode'],
                'Potential Effect': fm['effect'],
                'Severity': fm['severity'],
                'Potential Causes': fm['causes'],
                'Occurrence': fm['occurrence'],
                'Current Controls': fm['current_controls'],
                'Detection': fm['detection'],
                'RPN': rpn,
                'Priority': priority,
                'Action Required': action,
                'Recommended Mitigation': fm.get('mitigation', ''),
                'Owner': fm.get('owner', 'TBD'),
                'Target Date': fm.get('target_date', 'TBD')
            }
            
            fmea_data.append(row)
        
        df = pd.DataFrame(fmea_data)
        df = df.sort_values('RPN', ascending=False).reset_index(drop=True)
        
        return df
    
    def calculate_residual_rpn(self,
                               original_severity: int,
                               original_occurrence: int,
                               original_detection: int,
                               mitigation_effect: Dict[str, float]) -> int:
        """
        Calculate residual RPN after mitigation.
        
        Args:
            original_*: Original ratings
            mitigation_effect: Dict with reduction factors (0-1) for:
                - 'severity_reduction': How much severity is reduced
                - 'occurrence_reduction': How much occurrence is reduced
                - 'detection_improvement': How much detection is improved
                
        Returns:
            Residual RPN
        """
        new_severity = max(1, int(original_severity * (1 - mitigation_effect.get('severity_reduction', 0))))
        new_occurrence = max(1, int(original_occurrence * (1 - mitigation_effect.get('occurrence_reduction', 0))))
        new_detection = max(1, int(original_detection * (1 - mitigation_effect.get('detection_improvement', 0))))
        
        return self.calculate_rpn(new_severity, new_occurrence, new_detection)
    
    def pareto_analysis(self, fmea_df: pd.DataFrame, save_path: str = None):
        """
        Create Pareto chart of risks.
        
        Shows cumulative % of total risk.
        """
        # Calculate cumulative percentage
        fmea_sorted = fmea_df.sort_values('RPN', ascending=False).copy()
        fmea_sorted['Cumulative RPN'] = fmea_sorted['RPN'].cumsum()
        total_rpn = fmea_sorted['RPN'].sum()
        fmea_sorted['Cumulative %'] = (fmea_sorted['Cumulative RPN'] / total_rpn) * 100
        
        # Plot
        fig, ax1 = plt.subplots(figsize=(14, 6))
        
        # Bar chart
        x_pos = np.arange(len(fmea_sorted))
        ax1.bar(x_pos, fmea_sorted['RPN'], color='steelblue', alpha=0.7)
        ax1.set_xlabel('Failure Mode (Ranked by RPN)')
        ax1.set_ylabel('RPN', color='steelblue')
        ax1.tick_params(axis='y', labelcolor='steelblue')
        ax1.set_xticks(x_pos)
        ax1.set_xticklabels(fmea_sorted.index, rotation=45, ha='right')
        
        # Line chart for cumulative %
        ax2 = ax1.twinx()
        ax2.plot(x_pos, fmea_sorted['Cumulative %'], 'ro-', linewidth=2, markersize=6)
        ax2.set_ylabel('Cumulative % of Total Risk', color='red')
        ax2.tick_params(axis='y', labelcolor='red')
        ax2.axhline(80, color='orange', linestyle='--', alpha=0.7, label='80% Line')
        ax2.set_ylim(0, 105)
        
        plt.title('Pareto Chart: AI Risk Analysis')
        ax2.legend(loc='lower right')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Pareto chart saved to: {save_path}")
        
        plt.show()
        
        # Find 80% threshold
        idx_80 = (fmea_sorted['Cumulative %'] >= 80).idxmax()
        top_risks = fmea_sorted.loc[:idx_80]
        
        print(f"\n80/20 Analysis:")
        print(f"  Top {len(top_risks)} risks (out of {len(fmea_sorted)}) account for 80% of total risk")
        print(f"  Focus mitigation efforts on these {len(top_risks)} failure modes")
        
        return top_risks
    
    def risk_matrix_plot(self, fmea_df: pd.DataFrame, save_path: str = None):
        """
        Create risk matrix (Severity × Occurrence).
        """
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Create scatter plot
        scatter = ax.scatter(
            fmea_df['Occurrence'],
            fmea_df['Severity'],
            s=fmea_df['RPN'] / 2,  # Size proportional to RPN
            c=fmea_df['RPN'],
            cmap='YlOrRd',
            alpha=0.6,
            edgecolors='black',
            linewidths=1
        )
        
        # Add colorbar
        cbar = plt.colorbar(scatter, ax=ax)
        cbar.set_label('RPN', rotation=270, labelpad=20)
        
        # Add labels for each point
        for idx, row in fmea_df.iterrows():
            ax.annotate(
                idx,
                xy=(row['Occurrence'], row['Severity']),
                xytext=(5, 5),
                textcoords='offset points',
                fontsize=8
            )
        
        # Risk zones
        ax.axhspan(7, 10, alpha=0.1, color='red', label='High Severity')
        ax.axvspan(7, 10, alpha=0.1, color='orange', label='High Occurrence')
        
        ax.set_xlabel('Occurrence (1=Remote, 10=Very High)', fontsize=12)
        ax.set_ylabel('Severity (1=Negligible, 10=Catastrophic)', fontsize=12)
        ax.set_title('Risk Matrix: Severity vs Occurrence', fontsize=14)
        ax.grid(True, alpha=0.3)
        ax.set_xlim(0, 11)
        ax.set_ylim(0, 11)
        ax.legend(loc='upper left')
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Risk matrix saved to: {save_path}")
        
        plt.show()
    
    def export_to_excel(self, fmea_df: pd.DataFrame, filepath: str):
        """
        Export FMEA table to Excel with formatting.
        """
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            fmea_df.to_excel(writer, sheet_name='FMEA', index=False)
            
            # Get workbook and worksheet
            workbook = writer.book
            worksheet = writer.sheets['FMEA']
            
            # Auto-adjust column widths
            for idx, col in enumerate(fmea_df.columns):
                max_length = max(
                    fmea_df[col].astype(str).apply(len).max(),
                    len(col)
                )
                worksheet.column_dimensions[chr(65 + idx)].width = min(max_length + 2, 50)
            
        print(f"FMEA table exported to: {filepath}")


# Example usage
if __name__ == "__main__":
    print("=" * 100)
    print("AI ACT QMS - AI-FMEA RISK ASSESSMENT")
    print("=" * 100)
    
    # Initialize calculator
    calc = AIFMEACalculator()
    
    # Define AI-specific failure modes
    ai_failure_modes = [
        {
            'failure_mode': 'Systematic Gender Bias',
            'effect': 'Discrimination against female candidates in hiring',
            'severity': 9,  # Fundamental rights violation
            'causes': 'Unbalanced training data (80% male historical hires)',
            'occurrence': 7,  # High probability without mitigation
            'current_controls': 'None',
            'detection': 8,  # Would be rarely detected without fairness testing
            'mitigation': 'Fairness constraints, resampling, monthly bias monitoring',
            'owner': 'ML Engineer',
            'target_date': 'Q1 2025'
        },
        {
            'failure_mode': 'Model Drift (Concept Drift)',
            'effect': 'Performance degradation, wrong credit decisions',
            'severity': 8,
            'causes': 'Economic changes, market shifts',
            'occurrence': 6,
            'current_controls': 'Quarterly retraining',
            'detection': 7,
            'mitigation': 'PSI monitoring (daily), auto-retraining triggers',
            'owner': 'Risk Manager',
            'target_date': 'Q1 2025'
        },
        {
            'failure_mode': 'Hallucinations (LLM)',
            'effect': 'False information provided to customers',
            'severity': 7,
            'causes': 'Inherent LLM limitation, training data noise',
            'occurrence': 5,
            'current_controls': 'Confidence thresholds (>0.8)',
            'detection': 6,
            'mitigation': 'Human review for low confidence, fact-checking layer',
            'owner': 'Product Owner',
            'target_date': 'Q2 2025'
        },
        {
            'failure_mode': 'Data Poisoning Attack',
            'effect': 'Backdoored model, systematic failures',
            'severity': 10,
            'causes': 'Compromised data source, insider threat',
            'occurrence': 2,
            'current_controls': 'Data validation, trusted sources only',
            'detection': 9,
            'mitigation': 'Data provenance tracking, anomaly detection',
            'owner': 'Security Team',
            'target_date': 'Q2 2025'
        },
        {
            'failure_mode': 'Insufficient Human Oversight',
            'effect': 'EU AI Act Art. 14 violation, regulatory fines',
            'severity': 9,
            'causes': 'Fully automated process, no review mechanism',
            'occurrence': 4,
            'current_controls': 'None',
            'detection': 5,
            'mitigation': 'Mandatory human review workflow for high-stakes decisions',
            'owner': 'Compliance',
            'target_date': 'Q1 2025'
        },
        {
            'failure_mode': 'API Failure / Downtime',
            'effect': 'Business process disruption',
            'severity': 6,
            'causes': 'Infrastructure issues, overload',
            'occurrence': 4,
            'current_controls': 'Monitoring, SLA',
            'detection': 2,
            'mitigation': 'Redundancy, caching, graceful degradation',
            'owner': 'MLOps',
            'target_date': 'Q1 2025'
        }
    ]
    
    # Create FMEA table
    print("\n1. CREATING AI-FMEA TABLE")
    print("-" * 100)
    
    fmea_df = calc.create_fmea_table(ai_failure_modes)
    
    print(fmea_df[['Failure Mode', 'Severity', 'Occurrence', 'Detection', 'RPN', 'Priority']].to_string(index=False))
    
    # Summary statistics
    print(f"\n\nSUMMARY STATISTICS:")
    print(f"  Total Risks Identified: {len(fmea_df)}")
    print(f"  Critical Risks (RPN > 400): {len(fmea_df[fmea_df['Priority'] == 'Critical'])}")
    print(f"  High Risks (RPN 200-400): {len(fmea_df[fmea_df['Priority'] == 'High'])}")
    print(f"  Medium Risks (RPN 100-200): {len(fmea_df[fmea_df['Priority'] == 'Medium'])}")
    print(f"  Low Risks (RPN < 100): {len(fmea_df[fmea_df['Priority'] == 'Low'])}")
    
    # Critical risks
    critical_risks = fmea_df[fmea_df['Priority'] == 'Critical']
    if len(critical_risks) > 0:
        print(f"\n\n🚨 CRITICAL RISKS (RPN > 400):")
        for idx, risk in critical_risks.iterrows():
            print(f"\n  {idx+1}. {risk['Failure Mode']} (RPN={risk['RPN']})")
            print(f"     Effect: {risk['Potential Effect']}")
            print(f"     Mitigation: {risk['Recommended Mitigation']}")
            print(f"     Owner: {risk['Owner']}")
    
    # 2. Pareto Analysis
    print("\n\n2. PARETO ANALYSIS (80/20 RULE)")
    print("-" * 100)
    
    top_risks = calc.pareto_analysis(fmea_df, save_path='/tmp/ai_fmea_pareto.png')
    
    # 3. Risk Matrix
    print("\n\n3. RISK MATRIX")
    print("-" * 100)
    
    calc.risk_matrix_plot(fmea_df, save_path='/tmp/ai_risk_matrix.png')
    
    # 4. Residual RPN after mitigation
    print("\n\n4. RESIDUAL RISK CALCULATION (POST-MITIGATION)")
    print("-" * 100)
    
    # Example: Gender Bias mitigation
    gender_bias = ai_failure_modes[0]
    
    print(f"\nFailure Mode: {gender_bias['failure_mode']}")
    print(f"Original RPN: {calc.calculate_rpn(gender_bias['severity'], gender_bias['occurrence'], gender_bias['detection'])}")
    
    # Mitigation effects
    mitigation = {
        'severity_reduction': 0.0,  # Can't reduce severity (still fundamental rights)
        'occurrence_reduction': 0.6,  # Fairness constraints reduce occurrence by 60%
        'detection_improvement': 0.7  # Monthly monitoring improves detection by 70%
    }
    
    residual_rpn = calc.calculate_residual_rpn(
        gender_bias['severity'],
        gender_bias['occurrence'],
        gender_bias['detection'],
        mitigation
    )
    
    print(f"Residual RPN (post-mitigation): {residual_rpn}")
    print(f"RPN Reduction: {calc.calculate_rpn(gender_bias['severity'], gender_bias['occurrence'], gender_bias['detection']) - residual_rpn}")
    print(f"New Priority: {calc.classify_priority(residual_rpn)[0]}")
    
    # 5. Export to Excel
    print("\n\n5. EXPORTING FMEA TO EXCEL")
    print("-" * 100)
    
    calc.export_to_excel(fmea_df, '/tmp/ai_fmea_table.xlsx')
    
    # 6. AI Act Compliance Check
    print("\n\n📋 AI ACT ART. 9 COMPLIANCE SUMMARY")
    print("-" * 100)
    
    print("Risikomanagement Requirements:")
    print(f"  ✅ Risks identified: {len(fmea_df)} AI-specific failure modes")
    print(f"  ✅ Risks assessed: Severity × Occurrence × Detection")
    print(f"  ✅ Prioritization: RPN-based (Critical > High > Medium > Low)")
    
    if len(critical_risks) > 0:
        print(f"\n  ⚠️  ACTION REQUIRED: {len(critical_risks)} CRITICAL risks need immediate mitigation")
        print("     → Develop mitigation strategies within 30 days")
        print("     → Document in Risk Register")
        print("     → Track in Evidence Log")
    else:
        print("\n  ✅ No critical risks identified")
    
    high_risks = fmea_df[fmea_df['Priority'] == 'High']
    if len(high_risks) > 0:
        print(f"\n  ⚠️  {len(high_risks)} HIGH risks require action within 3 months")
    
    print("\n  ✅ Mitigation strategies documented for all risks")
    print("  ✅ Owners assigned for all critical and high risks")
    print("  ✅ Target dates set for mitigation implementation")
    
    print("\n" + "=" * 100)
    print("END OF AI-FMEA ASSESSMENT")
    print("=" * 100)
