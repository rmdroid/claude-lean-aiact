"""
AI Act QMS - Bias & Fairness Detection Module

Implements fairness metrics for AI model monitoring:
- Demographic Parity (Statistical Parity)
- Equalized Odds (Equal Opportunity)
- Disparate Impact Ratio
- Predictive Parity
- Individual Fairness Checks

Author: AI Act QMS Skill
Version: 1.0
"""

import numpy as np
import pandas as pd
from typing import Dict, Tuple, List
import warnings

warnings.filterwarnings('ignore')


class BiasDetector:
    """
    Comprehensive bias and fairness detection for AI models.
    
    Implements metrics aligned with EU AI Act Art. 9 requirements:
    - Group fairness metrics
    - Individual fairness checks
    - Intersectional fairness analysis
    """
    
    def __init__(self, 
                 sensitive_features: List[str],
                 threshold_disparate_impact: float = 0.8,
                 threshold_demographic_parity: float = 0.05,
                 threshold_equalized_odds: float = 0.05):
        """
        Initialize bias detector.
        
        Args:
            sensitive_features: List of protected attribute names
            threshold_disparate_impact: Minimum acceptable ratio (default 0.8 = 80% rule)
            threshold_demographic_parity: Maximum acceptable difference
            threshold_equalized_odds: Maximum acceptable difference
        """
        self.sensitive_features = sensitive_features
        self.threshold_di = threshold_disparate_impact
        self.threshold_dp = threshold_demographic_parity
        self.threshold_eo = threshold_equalized_odds
    
    def demographic_parity(self,
                          predictions: np.ndarray,
                          sensitive_attribute: np.ndarray,
                          privileged_group: any) -> Dict[str, any]:
        """
        Calculate Demographic Parity (Statistical Parity).
        
        Measures difference in positive prediction rates between groups.
        Fair if P(Ŷ=1|A=privileged) ≈ P(Ŷ=1|A=unprivileged)
        
        Args:
            predictions: Binary predictions (0/1)
            sensitive_attribute: Protected attribute (e.g., gender, race)
            privileged_group: Value representing privileged group
            
        Returns:
            Dictionary with fairness metrics
        """
        # Split by groups
        privileged_mask = sensitive_attribute == privileged_group
        unprivileged_mask = ~privileged_mask
        
        # Calculate positive rates
        privileged_rate = np.mean(predictions[privileged_mask])
        unprivileged_rate = np.mean(predictions[unprivileged_mask])
        
        # Difference and ratio
        difference = privileged_rate - unprivileged_rate
        ratio = unprivileged_rate / privileged_rate if privileged_rate > 0 else 0
        
        # Status
        if abs(difference) <= self.threshold_dp:
            status = "✅ Fair"
        elif abs(difference) <= self.threshold_dp * 2:
            status = "⚠️  Moderate bias"
        else:
            status = "❌ Significant bias"
        
        return {
            'Metric': 'Demographic Parity',
            'Privileged_Group': str(privileged_group),
            'Privileged_Rate': round(privileged_rate, 4),
            'Unprivileged_Rate': round(unprivileged_rate, 4),
            'Difference': round(difference, 4),
            'Ratio': round(ratio, 4),
            'Threshold': self.threshold_dp,
            'Status': status,
            'Recommendation': 'No action' if abs(difference) <= self.threshold_dp 
                            else 'Investigate' if abs(difference) <= self.threshold_dp * 2
                            else 'Mitigation required'
        }
    
    def equalized_odds(self,
                      predictions: np.ndarray,
                      true_labels: np.ndarray,
                      sensitive_attribute: np.ndarray,
                      privileged_group: any) -> Dict[str, any]:
        """
        Calculate Equalized Odds.
        
        Measures difference in True Positive Rates and False Positive Rates.
        Fair if TPR and FPR are similar across groups.
        
        Args:
            predictions: Binary predictions (0/1)
            true_labels: Actual labels (0/1)
            sensitive_attribute: Protected attribute
            privileged_group: Value representing privileged group
            
        Returns:
            Dictionary with fairness metrics
        """
        # Split by groups
        privileged_mask = sensitive_attribute == privileged_group
        unprivileged_mask = ~privileged_mask
        
        # TPR (Sensitivity/Recall) for each group
        # TPR = TP / (TP + FN)
        privileged_positives = true_labels[privileged_mask] == 1
        unprivileged_positives = true_labels[unprivileged_mask] == 1
        
        if privileged_positives.sum() > 0:
            tpr_privileged = np.mean(predictions[privileged_mask][privileged_positives])
        else:
            tpr_privileged = 0
            
        if unprivileged_positives.sum() > 0:
            tpr_unprivileged = np.mean(predictions[unprivileged_mask][unprivileged_positives])
        else:
            tpr_unprivileged = 0
        
        # FPR for each group
        # FPR = FP / (FP + TN)
        privileged_negatives = true_labels[privileged_mask] == 0
        unprivileged_negatives = true_labels[unprivileged_mask] == 0
        
        if privileged_negatives.sum() > 0:
            fpr_privileged = np.mean(predictions[privileged_mask][privileged_negatives])
        else:
            fpr_privileged = 0
            
        if unprivileged_negatives.sum() > 0:
            fpr_unprivileged = np.mean(predictions[unprivileged_mask][unprivileged_negatives])
        else:
            fpr_unprivileged = 0
        
        # Differences
        tpr_diff = tpr_privileged - tpr_unprivileged
        fpr_diff = fpr_privileged - fpr_unprivileged
        
        # Overall difference (max of TPR and FPR diff)
        max_diff = max(abs(tpr_diff), abs(fpr_diff))
        
        # Status
        if max_diff <= self.threshold_eo:
            status = "✅ Fair"
        elif max_diff <= self.threshold_eo * 2:
            status = "⚠️  Moderate bias"
        else:
            status = "❌ Significant bias"
        
        return {
            'Metric': 'Equalized Odds',
            'Privileged_Group': str(privileged_group),
            'TPR_Privileged': round(tpr_privileged, 4),
            'TPR_Unprivileged': round(tpr_unprivileged, 4),
            'TPR_Difference': round(tpr_diff, 4),
            'FPR_Privileged': round(fpr_privileged, 4),
            'FPR_Unprivileged': round(fpr_unprivileged, 4),
            'FPR_Difference': round(fpr_diff, 4),
            'Max_Difference': round(max_diff, 4),
            'Threshold': self.threshold_eo,
            'Status': status,
            'Recommendation': 'No action' if max_diff <= self.threshold_eo 
                            else 'Investigate' if max_diff <= self.threshold_eo * 2
                            else 'Mitigation required'
        }
    
    def disparate_impact(self,
                        predictions: np.ndarray,
                        sensitive_attribute: np.ndarray,
                        privileged_group: any) -> Dict[str, any]:
        """
        Calculate Disparate Impact Ratio (Four-Fifths Rule).
        
        Ratio of positive prediction rates between groups.
        Fair if ratio >= 0.8 (80% rule from US employment law)
        
        Args:
            predictions: Binary predictions (0/1)
            sensitive_attribute: Protected attribute
            privileged_group: Value representing privileged group
            
        Returns:
            Dictionary with fairness metrics
        """
        # Split by groups
        privileged_mask = sensitive_attribute == privileged_group
        unprivileged_mask = ~privileged_mask
        
        # Calculate positive rates
        privileged_rate = np.mean(predictions[privileged_mask])
        unprivileged_rate = np.mean(predictions[unprivileged_mask])
        
        # Disparate Impact Ratio
        di_ratio = unprivileged_rate / privileged_rate if privileged_rate > 0 else 0
        
        # Status based on 80% rule
        if di_ratio >= self.threshold_di:
            status = "✅ Acceptable (>= 80% rule)"
        elif di_ratio >= 0.70:
            status = "⚠️  Below threshold but close"
        else:
            status = "❌ Significant adverse impact"
        
        return {
            'Metric': 'Disparate Impact',
            'Privileged_Group': str(privileged_group),
            'Privileged_Rate': round(privileged_rate, 4),
            'Unprivileged_Rate': round(unprivileged_rate, 4),
            'Disparate_Impact_Ratio': round(di_ratio, 4),
            'Threshold': self.threshold_di,
            'Status': status,
            'Recommendation': 'No action' if di_ratio >= self.threshold_di
                            else 'Monitor closely' if di_ratio >= 0.70
                            else 'Immediate mitigation required'
        }
    
    def predictive_parity(self,
                         predictions: np.ndarray,
                         true_labels: np.ndarray,
                         sensitive_attribute: np.ndarray,
                         privileged_group: any) -> Dict[str, any]:
        """
        Calculate Predictive Parity (Precision Parity).
        
        Measures difference in Positive Predictive Value (Precision) across groups.
        Fair if PPV is similar: P(Y=1|Ŷ=1, A=privileged) ≈ P(Y=1|Ŷ=1, A=unprivileged)
        
        Args:
            predictions: Binary predictions (0/1)
            true_labels: Actual labels (0/1)
            sensitive_attribute: Protected attribute
            privileged_group: Value representing privileged group
            
        Returns:
            Dictionary with fairness metrics
        """
        # Split by groups
        privileged_mask = sensitive_attribute == privileged_group
        unprivileged_mask = ~privileged_mask
        
        # PPV (Precision) = TP / (TP + FP)
        privileged_pred_positive = predictions[privileged_mask] == 1
        unprivileged_pred_positive = predictions[unprivileged_mask] == 1
        
        if privileged_pred_positive.sum() > 0:
            ppv_privileged = np.mean(true_labels[privileged_mask][privileged_pred_positive])
        else:
            ppv_privileged = 0
            
        if unprivileged_pred_positive.sum() > 0:
            ppv_unprivileged = np.mean(true_labels[unprivileged_mask][unprivileged_pred_positive])
        else:
            ppv_unprivileged = 0
        
        # Difference
        ppv_diff = ppv_privileged - ppv_unprivileged
        
        # Status
        if abs(ppv_diff) <= self.threshold_dp:  # Using same threshold as demographic parity
            status = "✅ Fair"
        elif abs(ppv_diff) <= self.threshold_dp * 2:
            status = "⚠️  Moderate bias"
        else:
            status = "❌ Significant bias"
        
        return {
            'Metric': 'Predictive Parity',
            'Privileged_Group': str(privileged_group),
            'PPV_Privileged': round(ppv_privileged, 4),
            'PPV_Unprivileged': round(ppv_unprivileged, 4),
            'Difference': round(ppv_diff, 4),
            'Threshold': self.threshold_dp,
            'Status': status,
            'Recommendation': 'No action' if abs(ppv_diff) <= self.threshold_dp
                            else 'Investigate' if abs(ppv_diff) <= self.threshold_dp * 2
                            else 'Mitigation required'
        }
    
    def comprehensive_report(self,
                            predictions: np.ndarray,
                            true_labels: np.ndarray,
                            data: pd.DataFrame,
                            privileged_groups: Dict[str, any]) -> pd.DataFrame:
        """
        Generate comprehensive fairness report for all sensitive features.
        
        Args:
            predictions: Binary predictions
            true_labels: Actual labels
            data: DataFrame containing sensitive features
            privileged_groups: Dict mapping feature name to privileged group value
            
        Returns:
            DataFrame with all fairness metrics
        """
        results = []
        
        for feature in self.sensitive_features:
            if feature not in data.columns:
                print(f"Warning: {feature} not found in data")
                continue
            
            if feature not in privileged_groups:
                print(f"Warning: Privileged group not specified for {feature}")
                continue
            
            sensitive_attr = data[feature].values
            privileged = privileged_groups[feature]
            
            # Calculate all metrics
            dp = self.demographic_parity(predictions, sensitive_attr, privileged)
            eo = self.equalized_odds(predictions, true_labels, sensitive_attr, privileged)
            di = self.disparate_impact(predictions, sensitive_attr, privileged)
            pp = self.predictive_parity(predictions, true_labels, sensitive_attr, privileged)
            
            results.append({
                'Feature': feature,
                'Metric': 'Demographic Parity',
                'Value': dp['Difference'],
                'Status': dp['Status'],
                'Recommendation': dp['Recommendation']
            })
            
            results.append({
                'Feature': feature,
                'Metric': 'Equalized Odds',
                'Value': eo['Max_Difference'],
                'Status': eo['Status'],
                'Recommendation': eo['Recommendation']
            })
            
            results.append({
                'Feature': feature,
                'Metric': 'Disparate Impact',
                'Value': di['Disparate_Impact_Ratio'],
                'Status': di['Status'],
                'Recommendation': di['Recommendation']
            })
            
            results.append({
                'Feature': feature,
                'Metric': 'Predictive Parity',
                'Value': pp['Difference'],
                'Status': pp['Status'],
                'Recommendation': pp['Recommendation']
            })
        
        return pd.DataFrame(results)
    
    def intersectional_analysis(self,
                               predictions: np.ndarray,
                               true_labels: np.ndarray,
                               data: pd.DataFrame,
                               feature_combinations: List[Tuple[str, str]]) -> pd.DataFrame:
        """
        Analyze intersectional fairness (multiple protected attributes).
        
        Example: Gender × Race
        
        Args:
            predictions: Binary predictions
            true_labels: Actual labels
            data: DataFrame containing sensitive features
            feature_combinations: List of tuples with feature pairs
            
        Returns:
            DataFrame with intersectional fairness metrics
        """
        results = []
        
        for feat1, feat2 in feature_combinations:
            # Create combined groups
            data['_combined'] = data[feat1].astype(str) + '_' + data[feat2].astype(str)
            
            groups = data['_combined'].unique()
            
            for group in groups:
                group_mask = data['_combined'] == group
                
                if group_mask.sum() < 10:  # Skip very small groups
                    continue
                
                group_preds = predictions[group_mask]
                group_labels = true_labels[group_mask]
                
                # Calculate metrics for this intersectional group
                positive_rate = np.mean(group_preds)
                
                if (group_labels == 1).sum() > 0:
                    tpr = np.mean(group_preds[group_labels == 1])
                else:
                    tpr = 0
                
                if (group_labels == 0).sum() > 0:
                    fpr = np.mean(group_preds[group_labels == 0])
                else:
                    fpr = 0
                
                results.append({
                    'Feature_Combination': f"{feat1} × {feat2}",
                    'Group': group,
                    'Sample_Size': group_mask.sum(),
                    'Positive_Rate': round(positive_rate, 4),
                    'TPR': round(tpr, 4),
                    'FPR': round(fpr, 4)
                })
            
            data.drop('_combined', axis=1, inplace=True)
        
        return pd.DataFrame(results)


# Example usage
if __name__ == "__main__":
    # Generate synthetic data for demonstration
    np.random.seed(42)
    n_samples = 1000
    
    # Create synthetic dataset with bias
    data = pd.DataFrame({
        'gender': np.random.choice(['Male', 'Female'], n_samples, p=[0.6, 0.4]),
        'race': np.random.choice(['White', 'Black', 'Hispanic'], n_samples, p=[0.7, 0.2, 0.1]),
        'age': np.random.normal(40, 12, n_samples)
    })
    
    # Simulate biased predictions (model favors Male and White)
    base_prob = 0.5
    gender_bias = np.where(data['gender'] == 'Male', 0.15, -0.15)
    race_bias = np.where(data['race'] == 'White', 0.10, 
                         np.where(data['race'] == 'Black', -0.10, -0.05))
    
    prob = base_prob + gender_bias + race_bias
    prob = np.clip(prob, 0, 1)
    predictions = (np.random.random(n_samples) < prob).astype(int)
    
    # True labels (less biased)
    true_prob = 0.5 + 0.05 * gender_bias + 0.03 * race_bias
    true_prob = np.clip(true_prob, 0, 1)
    true_labels = (np.random.random(n_samples) < true_prob).astype(int)
    
    # Initialize detector
    detector = BiasDetector(
        sensitive_features=['gender', 'race'],
        threshold_disparate_impact=0.8,
        threshold_demographic_parity=0.05,
        threshold_equalized_odds=0.05
    )
    
    print("=" * 100)
    print("AI ACT QMS - BIAS & FAIRNESS DETECTION REPORT")
    print("=" * 100)
    
    # 1. Gender Analysis
    print("\n1. GENDER FAIRNESS ANALYSIS")
    print("-" * 100)
    
    dp_gender = detector.demographic_parity(predictions, data['gender'].values, 'Male')
    print("\nDemographic Parity:")
    for key, value in dp_gender.items():
        print(f"  {key:25s}: {value}")
    
    eo_gender = detector.equalized_odds(predictions, true_labels, data['gender'].values, 'Male')
    print("\nEqualized Odds:")
    for key, value in eo_gender.items():
        print(f"  {key:25s}: {value}")
    
    di_gender = detector.disparate_impact(predictions, data['gender'].values, 'Male')
    print("\nDisparate Impact:")
    for key, value in di_gender.items():
        print(f"  {key:25s}: {value}")
    
    # 2. Race Analysis
    print("\n\n2. RACE FAIRNESS ANALYSIS")
    print("-" * 100)
    
    di_race = detector.disparate_impact(predictions, data['race'].values, 'White')
    print("\nDisparate Impact:")
    for key, value in di_race.items():
        print(f"  {key:25s}: {value}")
    
    # 3. Comprehensive Report
    print("\n\n3. COMPREHENSIVE FAIRNESS REPORT")
    print("-" * 100)
    
    privileged_groups = {
        'gender': 'Male',
        'race': 'White'
    }
    
    report = detector.comprehensive_report(
        predictions=predictions,
        true_labels=true_labels,
        data=data,
        privileged_groups=privileged_groups
    )
    
    print(report.to_string(index=False))
    
    # 4. Intersectional Analysis
    print("\n\n4. INTERSECTIONAL FAIRNESS ANALYSIS (Gender × Race)")
    print("-" * 100)
    
    intersectional = detector.intersectional_analysis(
        predictions=predictions,
        true_labels=true_labels,
        data=data,
        feature_combinations=[('gender', 'race')]
    )
    
    print(intersectional.to_string(index=False))
    
    # 5. AI Act Compliance Summary
    print("\n\n📋 AI ACT ART. 9 COMPLIANCE SUMMARY")
    print("-" * 100)
    
    critical_issues = report[report['Status'].str.contains('❌')]
    if len(critical_issues) > 0:
        print("⚠️  CRITICAL: Significant bias detected!")
        print("\nFairness violations:")
        for _, row in critical_issues.iterrows():
            print(f"  • {row['Feature']} - {row['Metric']}: {row['Status']}")
            print(f"    → {row['Recommendation']}")
        
        print("\n🚨 IMMEDIATE ACTIONS REQUIRED:")
        print("  1. Escalate to Model Risk Manager within 24 hours")
        print("  2. Activate Bias Incident Response SOP (SOP-AI-002)")
        print("  3. Consider model deactivation if fundamental rights at risk")
        print("  4. Initiate root cause analysis (5-Why)")
        print("  5. Document in Evidence Log (Art. 9 compliance)")
    else:
        print("✅ No critical bias detected")
        print("   All fairness metrics within acceptable thresholds")
        print("   Continue monthly bias monitoring as per Monitoring Plan (Art. 72)")
    
    print("\n" + "=" * 100)
    print("END OF BIAS DETECTION REPORT")
    print("=" * 100)
