# EU AI Act Compliance QMS Skill

## Überblick

Dieser Claude Skill operationalisiert ein EU AI Act konformes Qualitätsmanagementsystem für High-Risk AI-Systeme. Er nutzt bewährte Lean Six Sigma DMAIC-Methodik, um die zentralen Compliance-Anforderungen strukturiert umzusetzen:

- **Art. 9**: Risikomanagement (kontinuierlich, iterativ, dokumentiert)
- **Art. 17**: Qualitätsmanagementsystem (Policies, Prozesse, Nachweise)
- **Art. 72**: Post-Market Monitoring (Verantwortlichkeiten, Schwellwerte, Eskalation)

## Das Problem

Der EU AI Act fordert bei High-Risk-AI konkrete Strukturen, aber vielen Unternehmen fehlt die Operationalisierung:

❌ Wer ist verantwortlich?  
❌ Welche KPIs?  
❌ Welche Eskalation bei Abweichungen?

**Konsequenz:** Bei Verstößen drohen Strafen bis **35 Mio € oder 7% des weltweiten Umsatzes** (je nachdem was höher ist).

## Die Lösung

Lean Six Sigma als bewährte Struktur, um das geforderte QMS operational zu machen:

✅ **DMAIC-Phasen** systematisch durch Compliance führen  
✅ **Klare Verantwortlichkeiten** (RACI-Matrizen)  
✅ **Messbare KPIs** (Performance, Bias, Drift)  
✅ **Definierte Eskalation** (Warning → Alert → Critical)  
✅ **Auditfähige Dokumentation** (Evidence Logs)

## Features

### 1. AI Act Assessment
- Risikoklassifizierung nach Art. 6 + Annex III
- Gap-Analyse gegen Art. 9, 17, 72
- Projektkomplexität und Roadmap

### 2. Risikomanagement (Art. 9)
- **AI-FMEA** mit spezifischen Failure Modes:
  - Bias (systematische Diskriminierung)
  - Model Drift (Performance Degradation)
  - Hallucinations (falsche Outputs)
  - Adversarial Attacks
  - Data Poisoning
  - Privacy Leakage
  
- **Risk Register** mit Fundamental Rights Mapping
- **5-Why Root Cause Analysis**
- **Pareto-Analyse** für Priorisierung

### 3. QMS Dokumentation (Art. 17)
- Policies & Procedures Templates
- Governance Operating Model
- Technical Documentation Framework
- Evidence Logs für Audits

### 4. Post-Market Monitoring (Art. 72)
- **Monitoring Plan** mit konkreten Schwellwerten:
  - Performance Metrics (wöchentlich)
  - Bias Metrics (monatlich)
  - Data Drift (täglich via PSI)
  - Prediction Drift (wöchentlich)
  
- **Eskalationsstufen**:
  - Warning (Gelb): 5 Tage Root Cause
  - Alert (Orange): 48h Mitigation Plan
  - Critical (Rot): 24h Emergency Meeting
  
- **Control Charts** für Statistical Process Control
- **SOPs**: Drift Response, Bias Incident Handling
- **Evidence Logs** für Audit Trail

### 5. Python Scripts

#### `drift_detection.py`
- Population Stability Index (PSI)
- Kolmogorov-Smirnov Test
- Prediction Drift Detection
- Data Quality Drift

#### `bias_detection.py`
- Demographic Parity
- Equalized Odds
- Disparate Impact Ratio (80% Rule)
- Predictive Parity
- Intersectional Fairness Analysis

## Verwendung

### Trigger

```
/start aiact     # Startet AI Act Compliance Assessment
/aiact risk      # Schnellzugriff Risikomanagement (Art. 9)
/aiact qms       # Schnellzugriff QMS Dokumentation (Art. 17)
/aiact monitor   # Schnellzugriff Post-Market Monitoring (Art. 72)
```

### Typischer Workflow

1. **Assessment starten**
   ```
   /start aiact
   ```
   → Risikoklassifizierung, Gap-Analyse, Roadmap

2. **Define Phase**
   - AI System Charter erstellen
   - SIPOC für AI Lifecycle
   - Governance-Struktur etablieren
   - Business Case quantifizieren

3. **Measure Phase**
   - Baseline Performance dokumentieren
   - Bias Assessment durchführen
   - Data Quality bewerten

4. **Analyze Phase**
   - AI-FMEA für Top-Risiken
   - Risk Register aufbauen (Art. 9 konform)
   - 5-Why für Root Causes

5. **Improve Phase**
   - Mitigation Strategies entwickeln
   - QMS Policies dokumentieren (Art. 17)
   - Governance operationalisieren

6. **Control Phase**
   - Monitoring Plan implementieren (Art. 72)
   - Control Charts aufsetzen
   - SOPs trainieren
   - Evidence Logs etablieren

## Deliverables

### Excel Templates
- AI System Charter
- AI SIPOC
- AI Governance RACI
- AI-FMEA
- Risk Register
- Mitigation Strategies Matrix
- Monitoring Plan
- Evidence Log

### PowerPoint Templates
- QMS Documentation
- Compliance Tollgate Reviews
- Audit Readiness Presentation

### SOPs
- Model Drift Response
- Bias Incident Handling
- Quarterly Compliance Review
- Annual Model Re-Validation

### Python Scripts
- Drift Detection (PSI, KS-Test)
- Bias Detection (Demographic Parity, Equalized Odds)
- AI Control Charts (I-MR, p-Charts, EWMA)

## Beispiel: Post-Market Monitoring für Recruiting AI

**Scenario:** Ein HR-Tech Unternehmen nutzt ein High-Risk AI-System für CV-Screening.

### Problem erkannt
- Monthly Bias Review zeigt: **Disparate Impact Ratio = 0.72** (< 0.80 Threshold)
- → Frauen werden systematisch benachteiligt

### Eskalation (gemäß Monitoring Plan)
- **Level 2 Alert** (Orange) ausgelöst
- Model Risk Manager informiert (automatisch)
- 48h Frist für Mitigation Plan

### Root Cause Analysis (5-Why)
1. Warum Bias? → Training Data 80% Male
2. Warum unbalanced? → Historical hiring patterns
3. Warum nicht korrigiert? → No fairness requirements
4. Warum keine Requirements? → AI Act awareness fehlte
5. Root: Fehlende Governance + Training

### Mitigation (gemäß SOP-AI-002)
1. **Sofortmaßnahme**: Human Review für alle Female Candidates
2. **Technisch**: Re-sampling + Fairness Constraints
3. **Prozess**: Mandatory Fairness Impact Assessment
4. **Training**: Team Enablement zu AI Act + Fairness

### Dokumentation (Art. 9, 72)
- Incident Report: INC-001-Bias-Gender
- Root Cause Analysis: RCA-001
- Mitigation Plan: MIT-001-Fairness
- Evidence Log Entry: EV-042

### Ergebnis
- Neues Model deployed mit DI Ratio = 0.85 ✅
- Risk Register updated (neue Kontrolle)
- Lessons Learned dokumentiert
- Quarterly Review angepasst

## Integration mit bestehenden Frameworks

- **ISO 42001** (AI Management System)
- **ISO 9001** (Quality Management)
- **GDPR** (Koordination mit DPO)
- **ISO 27001** (Information Security Alignment)

## Sanktions-Risiko Bewertung

Der Skill hilft bei der Quantifizierung des Sanktionsrisikos:

```
Sanktionsrisiko = P(Audit) × P(Feststellung|Non-Compliance) × Strafmaß

Beispiel Recruiting AI:
P(Audit) = 30% (high visibility)
P(Feststellung) = 80% (ohne Bias Monitoring)
Strafmaß = 35 Mio € oder 7% Umsatz

Expected Loss = 0.3 × 0.8 × 35 Mio = 8.4 Mio €
```

→ ROI für Compliance nachweisbar!

## Best Practices

1. **Früh starten**: Nicht erst bei Enforcement Deadline
2. **Iterativ vorgehen**: Quick Wins first, dann Transformation
3. **Cross-funktionale Teams**: Legal + Tech + Business
4. **Dokumentation from Day 1**: Evidence Logs aufbauen
5. **Automation wo möglich**: Monitoring, Alerts, Dashboards
6. **Regelmäßige Reviews**: Quarterly Risk Reviews nicht skippen
7. **Team trainieren**: SOPs nur wirksam wenn bekannt

## Quellen & Referenzen

- **EU AI Act** (Regulation 2024/1689)
  - Art. 6: Risikoklassifizierung
  - Art. 9: Risikomanagement
  - Art. 17: Qualitätsmanagementsystem
  - Art. 72: Post-Market Monitoring
  - Art. 73: Serious Incident Reporting
  - Annex III: Liste High-Risk AI Systems

- **Lean Six Sigma**
  - DMAIC Methodik
  - Statistical Process Control (SPC)
  - FMEA (Failure Mode and Effects Analysis)
  
- **Fairness Metrics**
  - Demographic Parity
  - Equalized Odds (Hardt et al., 2016)
  - Disparate Impact (80% Rule, US EEOC)

## Lizenz

Open Source - MIT License

## Autor

Erstellt als Claude Skill für EU AI Act Compliance Operationalisierung.  
Basierend auf Lean Six Sigma Master Black Belt Skill.

---

**Hinweis:** Dieser Skill ersetzt keine rechtliche Beratung. Bei Unsicherheiten sollte externe Legal Opinion eingeholt werden.
