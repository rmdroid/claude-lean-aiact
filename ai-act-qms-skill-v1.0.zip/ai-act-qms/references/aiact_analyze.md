# DMAIC Phase 3: Analyze – Risikomanagement (Art. 9)

## Ziel
AI-spezifische Risiken systematisch identifizieren, bewerten und priorisieren gemäß Art. 9 EU AI Act.

## AI Act Bezug

**Art. 9 - Risikomanagement System:**
> Das Risikomanagementsystem besteht aus einem kontinuierlichen iterativen Prozess über den gesamten Lebenszyklus eines KI-Systems und umfasst regelmäßige systematische Aktualisierungen.

**Anforderungen:**
1. Identifikation bekannter und vernünftigerweise vorhersehbarer Risiken
2. Abschätzung und Bewertung der Risiken im vorgesehenen Einsatz
3. Bewertung anderer möglicherweise entstehender Risiken
4. Annahme geeigneter Risikomanagementmaßnahmen
5. Dokumentation aller Schritte

## Schritt-für-Schritt Anleitung

### 1. AI Risk Taxonomy

**Kategorien von AI-spezifischen Risiken:**

#### A) Model Performance Risiken
- **Unzureichende Accuracy**: False Positives/Negatives
- **Low Precision**: Zu viele Fehlalarme
- **Low Recall**: Zu viele übersehene Cases
- **Overfitting**: Model funktioniert nur auf Training Data
- **Underfitting**: Model zu simpel für komplexe Patterns

#### B) Fairness & Bias Risiken
- **Historischer Bias**: Training Data spiegelt historische Diskriminierung
- **Representation Bias**: Unterrepräsentation bestimmter Gruppen
- **Measurement Bias**: Features messen unterschiedlich für Gruppen
- **Aggregation Bias**: One-size-fits-all Model für diverse Populationen
- **Evaluation Bias**: Test Set nicht repräsentativ
- **Deployment Bias**: Unterschiedliche Nutzung in verschiedenen Kontexten

#### C) Data Quality Risiken
- **Incomplete Data**: Fehlende Values systematisch
- **Inaccurate Data**: Fehlerhafte Labels
- **Outdated Data**: Training Data nicht aktuell
- **Unrepresentative Data**: Sampling nicht repräsentativ
- **Data Drift**: Production Data weicht von Training Data ab

#### D) Model Drift Risiken
- **Concept Drift**: Relationship zwischen Features und Target ändert sich
- **Covariate Drift**: Feature Distribution ändert sich
- **Label Drift**: Target Distribution ändert sich
- **Prediction Drift**: Model Outputs ändern sich

#### E) Adversarial Risiken
- **Evasion Attacks**: Inputs manipuliert um Model zu täuschen
- **Poisoning Attacks**: Training Data kompromittiert
- **Model Extraction**: Reverse Engineering des Models
- **Membership Inference**: Rekonstruktion von Training Data

#### F) Transparency & Explainability Risiken
- **Unexplainable Decisions**: Black Box ohne Begründung
- **Misleading Explanations**: SHAP/LIME nicht korrekt interpretiert
- **Insufficient Documentation**: Technical Docs unvollständig

#### G) Human Oversight Risiken
- **Automation Bias**: Menschen vertrauen zu sehr auf AI
- **Deskilling**: Menschen verlieren Fähigkeit manuelle Checks
- **Alert Fatigue**: Zu viele False Alarms → Ignorierung

### 2. AI-FMEA (Failure Mode and Effects Analysis)

**Template für AI-FMEA:**

| Failure Mode | Potential Effect | Severity (1-10) | Potential Causes | Occurrence (1-10) | Current Controls | Detection (1-10) | RPN | Recommended Actions | Responsibility | Target Date |
|--------------|------------------|-----------------|------------------|-------------------|------------------|------------------|-----|---------------------|----------------|-------------|
| Systematischer Bias gegen Frauen | Diskriminierung bei Recruiting | 9 | Unbalanced Training Data (80% Male) | 7 | Keine | 8 | 504 | Fairness Constraints, Resampling | ML Engineer | Q1 2025 |
| Model Drift bei Credit Scoring | Falsche Kreditentscheidungen | 8 | Wirtschaftliche Veränderungen | 6 | Quarterly Retraining | 7 | 336 | PSI Monitoring, Monthly Retraining | Risk Manager | Q1 2025 |
| Hallucinations bei LLM | Falsche Informationen an Kunden | 7 | Inherent Model Limitation | 5 | Confidence Thresholds | 6 | 210 | Human Review für Low Confidence | Product Owner | Q2 2025 |

**Bewertungsskalen:**

**Severity (Schweregrad):**
- 1-3: Negligible (geringe Auswirkung)
- 4-6: Marginal (moderate Auswirkung)
- 7-8: Critical (schwerwiegende Auswirkung auf Personen)
- 9-10: Catastrophic (schwerwiegende Grundrechtsverletzung)

**Occurrence (Auftrittswahrscheinlichkeit):**
- 1-2: Remote (sehr unwahrscheinlich, < 1%)
- 3-4: Low (unwahrscheinlich, 1-5%)
- 5-6: Moderate (gelegentlich, 5-20%)
- 7-8: High (wahrscheinlich, 20-50%)
- 9-10: Very High (sehr wahrscheinlich, > 50%)

**Detection (Entdeckungswahrscheinlichkeit):**
- 1-2: Very High (immer entdeckt, automatisches Monitoring)
- 3-4: High (meist entdeckt, regelmäßige Reviews)
- 5-6: Moderate (manchmal entdeckt, Stichproben)
- 7-8: Low (selten entdeckt, nur bei Eskalation)
- 9-10: Very Low (fast nie entdeckt vor Auswirkung)

**Risk Priority Number (RPN):**
```
RPN = Severity × Occurrence × Detection
```

**Priorisierung:**
- RPN > 400: **Critical** → Sofortige Mitigation erforderlich
- RPN 200-400: **High** → Mitigation innerhalb 3 Monate
- RPN 100-200: **Medium** → Mitigation innerhalb 6 Monate
- RPN < 100: **Low** → Monitoring, ggf. Akzeptanz

### 3. Risk Register (Art. 9 Konform)

**Template:**

```
RISK REGISTER – [AI System Name]

Document Control:
- Version: 1.0
- Date: [Datum]
- Owner: [Model Risk Manager]
- Review Frequency: Quarterly

Risk Matrix:

| Risk ID | Category | Risk Description | Impact on Fundamental Rights | Likelihood | Severity | Risk Level | Mitigation Measures | Residual Risk | Owner | Review Date |
|---------|----------|------------------|------------------------------|------------|----------|------------|---------------------|---------------|-------|-------------|
| R001 | Bias | Systematische Benachteiligung von Frauen im Recruiting | Art. 21 Charter (Gleichbehandlung) | High (7) | Critical (9) | 63 (Critical) | 1. Fairness Constraints 2. Resampling 3. Monthly Bias Monitoring | Medium (4) | ML Eng | Q1 2025 |
| R002 | Drift | Performance Degradation durch Concept Drift | Art. 47 Charter (Effektiver Rechtsschutz) | Moderate (5) | Marginal (6) | 30 (Medium) | 1. PSI Monitoring 2. Auto-Retraining | Low (2) | Risk Mgr | Q1 2025 |
```

**Risk Level Matrix:**
```
                    Likelihood →
                Remote  Low  Moderate  High  Very High
Severity    
↓
Catastrophic     Low    Med    High    Crit    Crit
Critical         Low    Med    High    High    Crit
Marginal         Low    Low    Med     Med     High
Negligible       Low    Low    Low     Med     Med
```

**Fundamental Rights Mapping:**

Wichtig für AI Act Art. 9: Welche Grundrechte betroffen?

- Art. 21 Charter: Nichtdiskriminierung
- Art. 8 Charter: Schutz personenbezogener Daten
- Art. 7 Charter: Achtung des Privat- und Familienlebens
- Art. 47 Charter: Recht auf wirksamen Rechtsbehelf

### 4. 5-Why Root Cause Analysis

**Für Top-Risiken (RPN > 200):**

**Beispiel: Bias gegen Frauen im Recruiting**

1. **Warum tritt Bias auf?**
   → Model lernt historische Patterns aus Training Data

2. **Warum sind historische Patterns diskriminierend?**
   → Training Data enthält 80% Male Hires (historisch)

3. **Warum ist Training Data unbalanced?**
   → Sampling Strategy berücksichtigt keine Fairness

4. **Warum wurde Fairness in Sampling nicht berücksichtigt?**
   → Requirements haben Fairness nicht spezifiziert

5. **Warum waren Fairness-Requirements nicht vorhanden?**
   → AI Act Awareness fehlte im Product Team

**Root Cause:** Fehlende AI Act Awareness + Fehlende Fairness Requirements

**Mitigation:**
1. Team Training zu AI Act & Fairness
2. Mandatory Fairness Impact Assessment in Requirements Phase
3. Fairness Constraints in Model Training (Demographic Parity)

### 5. Pareto-Analyse der Risiken

**Ziel:** 80/20 Regel identifizieren

Sortiere Risiken nach RPN und erstelle Cumulative % Chart:

```
Risk ID | RPN | Cumulative %
--------|-----|-------------
R001    | 504 | 35%
R002    | 336 | 58%
R003    | 210 | 73%
R004    | 180 | 85%
R005    | 120 | 93%
...
```

**Ergebnis:** Top 3 Risiken machen 73% des Gesamt-Risikos aus
→ Fokus Mitigation auf diese

### 6. Statistische Validierung (wo möglich)

**Bias Testing:**
```python
# Beispiel: Disparate Impact Ratio
approval_rate_women = 0.45
approval_rate_men = 0.60
disparate_impact = approval_rate_women / approval_rate_men
# Result: 0.75 (< 0.8 threshold → Bias detected)
```

**Drift Testing:**
```python
# PSI (Population Stability Index) für Feature Drift
import numpy as np

def psi(expected, actual, buckets=10):
    # Binning
    breakpoints = np.percentile(expected, np.linspace(0, 100, buckets + 1))
    expected_percents = np.histogram(expected, bins=breakpoints)[0] / len(expected)
    actual_percents = np.histogram(actual, bins=breakpoints)[0] / len(actual)
    
    # PSI Calculation
    psi_values = (actual_percents - expected_percents) * np.log(actual_percents / expected_percents)
    return np.sum(psi_values)

# Interpretation:
# PSI < 0.1: No significant shift
# PSI 0.1-0.25: Moderate shift → investigate
# PSI > 0.25: Significant shift → retrain model
```

## Deliverables

✅ **AI-FMEA mit allen identifizierten Failure Modes** (Excel)
✅ **Risk Register mit Fundamental Rights Mapping** (Excel)
✅ **5-Why Analysis für Top 10 Risiken** (Word/Excel)
✅ **Pareto Chart der Risiken** (Excel/PowerPoint)
✅ **Statistical Evidence für Bias/Drift** (Python Scripts + Reports)

## Tollgate Review Kriterien

Zur Freigabe für Improve Phase:

- [ ] Mindestens 20 Risiken identifiziert und in FMEA dokumentiert
- [ ] Alle Risiken mit RPN > 200 haben 5-Why Analysis
- [ ] Risk Register vollständig mit Fundamental Rights Mapping
- [ ] Pareto-Analyse zeigt Top-Risiken
- [ ] Alle High/Critical Risks haben Owner zugewiesen
- [ ] Statistical Evidence für Bias/Drift wo vorhanden
- [ ] Residual Risk für alle Risiken geschätzt

## Typische Herausforderungen

**"Wir haben keine statistischen Daten für Bias"**
→ Nutze Proxy-Metrics (z.B. Demographic Parity auf synthetic data)
→ Expert Assessment mit konservativen Annahmen
→ In Control Phase: Echte Daten sammeln

**"Zu viele Risiken identifiziert (100+)"**
→ Gruppiere ähnliche Risiken (Clustering)
→ Fokus auf High-Risk Use Cases first
→ Nutze Pareto-Prinzip: Top 20% der Risiken

**"Schwierig Severity zu bewerten"**
→ Nutze Fundamental Rights Framework
→ Frage: Welches Grundrecht betroffen? Wie schwerwiegend?
→ Konservatives Prinzip: Im Zweifel höher bewerten

## Best Practices

1. **Workshop mit Cross-Functional Team**: ML Engineers, Legal, Compliance, Business für FMEA
2. **Nutze AI Risk Catalogs**: Nicht alles neu erfinden (z.B. NIST AI RMF, ISO 42001)
3. **Dokumentiere Annahmen**: Jede Severity/Occurrence Bewertung begründen
4. **Iterativ**: Risk Register ist living document, nicht one-time
5. **Link zu DPIA (GDPR)**: Bei Personal Data → koordiniere mit Data Protection Impact Assessment

## Integration mit Art. 9 AI Act

**Art. 9 Compliance Checklist nach Analyze Phase:**

- [ ] **Identifikation bekannter Risiken**: AI-FMEA deckt ab
- [ ] **Identifikation vorhersehbarer Risiken**: Expert Workshops durchgeführt
- [ ] **Abschätzung Risiken im Einsatz**: Use Case Analysis in Risk Register
- [ ] **Bewertung anderer Risiken**: What-if Analysis für Edge Cases
- [ ] **Dokumentation**: FMEA, Risk Register, 5-Why vollständig
- [ ] **Kontinuierlich**: Review Frequency definiert (quarterly)
- [ ] **Iterativ**: Update Trigger definiert (z.B. bei Incidents, Model Updates)

## Next Steps → Improve Phase

Priorisierte Risiken mit RPN > 200 werden in Improve Phase mit Mitigation Strategies adressiert.
