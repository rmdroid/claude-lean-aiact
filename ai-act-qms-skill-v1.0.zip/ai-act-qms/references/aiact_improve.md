# DMAIC Phase 4: Improve – Mitigation & QMS Implementation

## Ziel
Identifizierte Risiken mitigieren, QMS etablieren, Governance operationalisieren und Pilot durchführen.

## AI Act Bezug
- **Art. 9**: Risikomanagementmaßnahmen implementieren
- **Art. 17**: QMS Policies und Procedures dokumentieren
- **Art. 14**: Human Oversight Mechanismen etablieren

## Schritt-für-Schritt Anleitung

### 1. Mitigation Strategy Matrix entwickeln

**Template für jeden identifizierten Risk:**

| Risk ID | Risk Description | RPN | Mitigation Strategy | Implementation | Owner | Target Date | Residual RPN |
|---------|------------------|-----|---------------------|----------------|-------|-------------|--------------|
| R001 | Gender Bias (DI=0.75) | 504 | Fairness Constraints + Resampling | Technical | ML Eng | Q1 2025 | 120 |
| R002 | Model Drift (PSI>0.25) | 336 | Auto-Retraining Pipeline | Technical | MLOps | Q1 2025 | 80 |
| R003 | Hallucinations (LLM) | 210 | Confidence Thresholds + Human Review | Process | Product | Q2 2025 | 60 |

### 2. Bias Mitigation Strategies

#### A) Pre-Processing (Training Data)

**Resampling:**
```python
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler

# Oversample minority group (e.g., Female)
smote = SMOTE(sampling_strategy='auto', random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_train, y_train)

# Or: Undersample majority group
rus = RandomUnderSampler(sampling_strategy='auto', random_state=42)
X_resampled, y_resampled = rus.fit_resample(X_train, y_train)
```

**Reweighting:**
```python
from sklearn.utils import class_weight

# Calculate sample weights to balance classes
sample_weights = class_weight.compute_sample_weight(
    class_weight='balanced',
    y=y_train
)

# Use in training
model.fit(X_train, y_train, sample_weight=sample_weights)
```

**Disparate Impact Remover:**
```python
from aif360.algorithms.preprocessing import DisparateImpactRemover

# Modify features to remove correlation with protected attribute
dir = DisparateImpactRemover(repair_level=0.8)
dataset_transformed = dir.fit_transform(dataset)
```

#### B) In-Processing (Model Training)

**Fairness Constraints:**
```python
from fairlearn.reductions import ExponentiatedGradient, DemographicParity

# Constraint: Demographic Parity
constraint = DemographicParity()

# Mitigator
mitigator = ExponentiatedGradient(
    estimator=base_model,
    constraints=constraint
)

mitigator.fit(X_train, y_train, sensitive_features=sensitive_train)
y_pred = mitigator.predict(X_test, sensitive_features=sensitive_test)
```

**Adversarial Debiasing:**
```python
from aif360.algorithms.inprocessing import AdversarialDebiasing

# Train model that is accurate but "adversary" can't predict sensitive attribute
debiaser = AdversarialDebiasing(
    unprivileged_groups=unprivileged,
    privileged_groups=privileged,
    scope_name='debiaser',
    num_epochs=50
)

debiaser.fit(dataset_train)
dataset_pred = debiaser.predict(dataset_test)
```

#### C) Post-Processing (Predictions)

**Threshold Optimization:**
```python
from fairlearn.postprocessing import ThresholdOptimizer

# Different decision thresholds for different groups
postprocessor = ThresholdOptimizer(
    estimator=trained_model,
    constraints="demographic_parity",
    objective="balanced_accuracy_score"
)

postprocessor.fit(X_train, y_train, sensitive_features=sensitive_train)
y_pred = postprocessor.predict(X_test, sensitive_features=sensitive_test)
```

**Calibration:**
```python
from sklearn.calibration import CalibratedClassifierCV

# Calibrate probabilities separately for each group
for group in ['Male', 'Female']:
    mask = sensitive_test == group
    calibrator = CalibratedClassifierCV(model, method='sigmoid', cv=3)
    calibrator.fit(X_train[mask], y_train[mask])
    y_pred[mask] = calibrator.predict(X_test[mask])
```

**Mitigation Strategy Selection Matrix:**

| Strategy | Pros | Cons | When to Use |
|----------|------|------|-------------|
| **Resampling** | Simple, no model changes | May lose information (undersampling), overfitting risk (oversampling) | Small datasets, clear imbalance |
| **Reweighting** | Retains all data, simple | Sensitive to outliers | Moderate imbalance |
| **Fairness Constraints** | Formal guarantees | Performance trade-off, complex | Regulatory requirements |
| **Adversarial Debiasing** | Strong debiasing | Computationally expensive, needs careful tuning | Deep learning models |
| **Threshold Optimization** | No retraining needed | Different thresholds per group (transparency issue) | Post-hoc fix, quick mitigation |

### 3. Drift Mitigation Strategies

#### Continuous Monitoring + Auto-Retraining

**Architecture:**
```
[Production Data] → [Drift Detection (PSI, KS)] → [Alert] → [Auto-Retrain Trigger]
                                    ↓
                            [Dashboard & Logs]
                                    ↓
                          [Risk Manager Review]
```

**Implementation:**
```python
# Pseudocode for Auto-Retrain Pipeline

def check_drift(production_data, baseline_data):
    psi = calculate_psi(production_data, baseline_data)
    
    if psi > 0.25:  # Critical threshold
        trigger_retrain(priority='high')
        notify_risk_manager()
    elif psi > 0.10:  # Warning threshold
        schedule_retrain(timeframe='1_week')
        notify_ml_engineer()
    else:
        log_metrics()

def trigger_retrain(priority):
    # 1. Collect recent production data
    recent_data = fetch_production_data(last_n_days=30)
    
    # 2. Combine with historical training data
    training_data = combine_datasets(recent_data, historical_data, ratio=0.3)
    
    # 3. Validate data quality
    if data_quality_score(training_data) < 0.70:
        escalate_to_data_team()
        return
    
    # 4. Retrain model
    new_model = train_model(training_data)
    
    # 5. Validate performance
    if validate_model(new_model) and validate_fairness(new_model):
        deploy_model(new_model)
        update_baseline(training_data)
    else:
        escalate_to_risk_manager()
```

**Retraining Strategies:**

| Strategy | Frequency | Data Window | Use Case |
|----------|-----------|-------------|----------|
| **Static** | Never | Fixed training set | Stable environment |
| **Periodic** | Monthly/Quarterly | Last 6-12 months | Gradual drift |
| **Trigger-Based** | On alert | Last 1-3 months | Sudden drift |
| **Continuous** | Weekly | Rolling window | Highly dynamic |

#### Online Learning (Incremental Updates)

```python
from sklearn.linear_model import SGDClassifier

# Online learning model
model = SGDClassifier(loss='log', warm_start=True)

# Initial training
model.fit(X_train, y_train)

# Incremental updates with new data
for new_batch in production_batches:
    model.partial_fit(new_batch.X, new_batch.y)
    
    # Validate after each update
    if performance_degraded(model):
        rollback_to_previous_version()
```

**Pros:**
- Fast adaptation to drift
- No need for full retraining

**Cons:**
- Risk of catastrophic forgetting
- Harder to audit (continuous change)
- May amplify bias over time

### 4. QMS Dokumentation (Art. 17)

#### A) Policies

**AI Development & Deployment Policy:**

```
POLICY: AI DEVELOPMENT & DEPLOYMENT

Version: 1.0
Effective Date: [Datum]
Owner: Chief AI Officer
Scope: All High-Risk AI Systems

1. PURPOSE
   This policy establishes requirements for development and deployment of
   High-Risk AI systems in compliance with EU AI Act.

2. SCOPE
   Applies to:
   - All AI systems classified as High-Risk (Art. 6, Annex III)
   - All employees and contractors involved in AI development

3. PRINCIPLES
   3.1 Fairness: All AI systems must be tested for bias before deployment
   3.2 Transparency: Technical documentation must be maintained
   3.3 Human Oversight: High-Risk AI requires human review capability
   3.4 Accountability: Clear ownership and decision rights
   3.5 Continuous Monitoring: Performance and fairness tracking mandatory

4. REQUIREMENTS
   
   4.1 Pre-Deployment
       - Risk Classification (Art. 6 assessment)
       - FMEA with RPN calculation
       - Fairness testing (all protected attributes)
       - Data quality assessment (DQ > 70%)
       - Technical documentation complete
       - Governance approval from AI Board
   
   4.2 Deployment
       - Staging environment validation first
       - A/B testing with holdout group
       - Monitoring infrastructure ready
       - Incident response plan documented
       - Rollback procedure tested
   
   4.3 Post-Deployment
       - Weekly performance monitoring
       - Monthly bias review
       - Quarterly risk assessment
       - Annual model re-validation
       - Continuous evidence log maintenance

5. ROLES & RESPONSIBILITIES
   
   AI Product Owner:
   - Business case and requirements
   - Stakeholder management
   - Go-live decision
   
   Model Risk Manager:
   - Art. 9 risk management
   - Monitoring plan definition
   - Escalation coordination
   
   ML Engineer:
   - Model development and testing
   - Technical documentation
   - Performance optimization
   
   Compliance Officer:
   - AI Act interpretation
   - Audit coordination
   - Regulatory reporting

6. EXCEPTIONS
   Exceptions to this policy require:
   - Written justification
   - Risk assessment
   - Approval from AI Governance Board + Legal
   - Documentation in Evidence Log

7. ENFORCEMENT
   Violations may result in:
   - Model deactivation
   - Disciplinary action
   - Regulatory non-compliance escalation

8. REVIEW
   This policy will be reviewed annually and updated as needed.
```

#### B) Procedures (SOPs)

**SOP: Model Development Procedure**

```
SOP-AI-003: Model Development Procedure

1. DEFINE PHASE (1-2 weeks)
   Input: Business problem, stakeholder requirements
   Activities:
   - Create AI System Charter
   - Classify risk (Art. 6)
   - Define success metrics
   - Identify protected attributes
   Output: Approved charter, RACI matrix
   Tollgate: Sponsor sign-off

2. MEASURE PHASE (2-3 weeks)
   Input: Data access, infrastructure
   Activities:
   - Collect and validate data
   - Assess data quality (DQ > 70% required)
   - Calculate baseline performance
   - Test for bias
   Output: Baseline report, DQ scorecard
   Tollgate: DQ > 70%, bias documented

3. ANALYZE PHASE (2-4 weeks)
   Input: Baseline data, requirements
   Activities:
   - Conduct AI-FMEA
   - Build risk register
   - Root cause analysis for gaps
   Output: FMEA, Risk Register, mitigation plan
   Tollgate: All High RPN risks have mitigation strategy

4. IMPROVE PHASE (4-8 weeks)
   Input: Mitigation strategies
   Activities:
   - Implement bias mitigation
   - Train model with fairness constraints
   - A/B test in staging
   - Document QMS procedures
   Output: Trained model, test results, QMS docs
   Tollgate: Performance targets met, fairness thresholds met

5. CONTROL PHASE (ongoing)
   Input: Deployed model
   Activities:
   - Setup monitoring dashboards
   - Activate alerting
   - Execute monitoring plan
   - Quarterly reviews
   Output: Monitoring reports, incident logs
   Tollgate: 3 months stable operation

QUALITY GATES:
- Cannot proceed to next phase without tollgate approval
- Exception requires AI Governance Board decision
- All decisions documented in Evidence Log
```

**SOP: Model Validation Procedure**

```
SOP-AI-004: Model Validation Procedure

1. TEST SET VALIDATION
   - Test set size: min. 20% of data, min. n=1000
   - Test set must be representative (chi-square test)
   - No data leakage from training

2. PERFORMANCE VALIDATION
   Criteria:
   - Overall accuracy > [target from charter]
   - All subgroup performance documented
   - Performance gap < 5% between protected groups
   
   If not met → retrain with mitigation

3. FAIRNESS VALIDATION
   Criteria:
   - Disparate Impact > 0.80 for all protected attributes
   - Demographic Parity Diff < 0.05
   - Equalized Odds Diff < 0.05
   
   If not met → implement fairness constraints

4. ROBUSTNESS VALIDATION
   - Test on edge cases (n=100 manual cases)
   - Adversarial examples (FGSM, PGD)
   - Out-of-distribution detection
   
   Pass rate: > 90% of edge cases handled correctly

5. EXPLAINABILITY VALIDATION
   - SHAP values calculated for n=100 samples
   - Top features align with business logic
   - No protected attributes in top 10 features
   
   If protected attribute influential → investigate

6. DOCUMENTATION
   - Validation Report (template: VAL-Template.docx)
   - Evidence Log Entry
   - Sign-off: ML Engineer + Model Risk Manager

7. APPROVAL
   Model can only be deployed after:
   - All validation criteria met
   - Validation Report approved
   - AI Governance Board go-ahead
```

#### C) Work Instructions

**Work Instruction: Fairness Testing Checklist**

```
WORK INSTRUCTION: Fairness Testing

For each protected attribute (Gender, Race, Age, etc.):

☐ 1. Identify privileged and unprivileged groups
      Example: Gender → Privileged=Male, Unprivileged=Female

☐ 2. Calculate Demographic Parity
      Script: python bias_detection.py --metric demographic_parity
      Threshold: Difference < 0.05

☐ 3. Calculate Equalized Odds
      Script: python bias_detection.py --metric equalized_odds
      Threshold: TPR Diff < 0.05, FPR Diff < 0.05

☐ 4. Calculate Disparate Impact
      Script: python bias_detection.py --metric disparate_impact
      Threshold: Ratio > 0.80

☐ 5. Document results in Fairness Test Report
      Template: /templates/fairness_test_report.xlsx

☐ 6. If any threshold violated:
      → Escalate to Model Risk Manager
      → Implement mitigation (see Mitigation Matrix)
      → Re-test after mitigation

☐ 7. Intersectional Analysis (if time permits)
      Combinations: Gender×Race, Gender×Age, Race×Age
      Flag: Any subgroup with <100 samples

☐ 8. Sign-off
      Tester: [Name, Date]
      Reviewer: [Model Risk Manager, Date]
```

### 5. Governance Operating Model

**AI Governance Board Charter:**

```
AI GOVERNANCE BOARD CHARTER

1. PURPOSE
   Oversight body for High-Risk AI systems ensuring EU AI Act compliance.

2. COMPOSITION
   - Chair: Chief Technology Officer
   - Members:
     • Chief Data Officer
     • Model Risk Manager
     • Chief Compliance Officer
     • Data Protection Officer
     • Legal Counsel (AI Act specialist)
     • Business Representative (Product Owner)

3. FREQUENCY
   - Regular meetings: Monthly
   - Emergency meetings: As needed (24h notice)

4. DECISION RIGHTS
   
   Requires Board Approval:
   - Go/No-Go for new High-Risk AI systems
   - Mitigation strategies for RPN > 400
   - Model deactivation decisions
   - Exception to policies
   - Budget > 100k € for compliance measures
   
   Delegated to Model Risk Manager:
   - Routine monitoring plan updates
   - Retraining approvals (if criteria met)
   - Risk register updates
   
   Delegated to ML Engineer:
   - Technical implementation details
   - Performance optimization (within constraints)

5. MEETING AGENDA
   - Review open incidents
   - Monthly bias reports
   - Quarterly risk reviews
   - New system proposals
   - Policy updates
   - Audit preparation

6. ESCALATION TO MANAGEMENT BOARD
   Triggers:
   - Critical incident (Art. 73 reporting required)
   - Regulatory inquiry
   - Fundamental rights violation
   - Sanction risk > 5 Mio €

7. DOCUMENTATION
   - Meeting minutes mandatory
   - Decision log in Evidence Log
   - Action items tracked in project tool
```

**Decision Rights Matrix (RACI):**

| Decision | Product Owner | Risk Manager | ML Engineer | MLOps | Compliance | Legal | Board |
|----------|---------------|--------------|-------------|-------|------------|-------|-------|
| New AI System Go/No-Go | C | C | C | I | C | C | **A** |
| Requirements Definition | **R/A** | C | C | I | C | I | I |
| Mitigation Strategy (RPN>400) | C | **R** | C | I | C | I | **A** |
| Model Architecture | C | I | **R/A** | C | I | I | I |
| Deployment Timing | **R** | C | C | **A** | I | I | I |
| Fairness Threshold | C | **R** | C | I | **A** | C | I |
| Monitoring Plan | C | **R/A** | C | C | C | I | I |
| Model Deactivation | C | **R** | I | C | C | C | **A** |
| Incident Response | I | **R/A** | **R** | **R** | C | I | I |
| Audit Coordination | I | C | I | I | **R/A** | C | I |

**Legend:** R=Responsible, A=Accountable, C=Consulted, I=Informed

### 6. Pilot & Testing

**Pilot Plan Template:**

```
PILOT PLAN – [AI System Name]

1. OBJECTIVES
   - Validate model performance in production-like environment
   - Test monitoring infrastructure
   - Validate fairness in real-world usage
   - Identify unforeseen issues

2. SCOPE
   - Duration: 4 weeks
   - User Base: 10% of total (selected randomly)
   - Geography: [specific region if applicable]
   - Use Cases: [subset if applicable]

3. SUCCESS CRITERIA
   Must Meet:
   - Accuracy > 0.90 (vs. target 0.92)
   - Disparate Impact > 0.78 (vs. target 0.80)
   - No critical incidents (Level 3)
   - User satisfaction > 4/5
   
   Nice to Have:
   - Cycle time reduction > 20%
   - Cost savings documented

4. MONITORING DURING PILOT
   - Daily performance check
   - Weekly bias review (expedited)
   - Real-time alerting active
   - User feedback collection

5. ROLLBACK CRITERIA
   Immediate rollback if:
   - Accuracy < 0.85
   - Disparate Impact < 0.70
   - Critical incident (fundamental rights)
   - > 10 user complaints per day

6. LEARNING OBJECTIVES
   - Actual vs. predicted drift rates
   - Alert false positive rate
   - Response time to incidents
   - User acceptance of AI decisions

7. DELIVERABLES
   - Weekly pilot reports
   - Final pilot evaluation report
   - Updated risk register
   - Lessons learned document
   - Go/No-Go recommendation
```

**Shadow Mode Testing:**
```
Alternative to full pilot: Run model in parallel without impacting decisions

Benefits:
- No risk to users
- Collect real production data
- Validate monitoring

Process:
1. Deploy model in "shadow mode"
2. Log predictions alongside human decisions
3. Compare: AI vs Human decisions
4. Analyze discrepancies
5. Fix issues before go-live
```

## Deliverables

✅ **Mitigation Strategy Matrix** (Excel)
✅ **QMS Policy Documentation** (Word/PDF)
✅ **SOPs (Model Dev, Validation, Change Management)** (Word/PDF)
✅ **Work Instructions (Fairness Testing, etc.)** (Word/PDF)
✅ **Governance Operating Model** (PowerPoint)
✅ **Pilot Plan & Results** (Word/PowerPoint)

## Tollgate Review Kriterien

Zur Freigabe für Control Phase:

- [ ] All High RPN risks have implemented mitigation (RPN reduced by >50%)
- [ ] Fairness thresholds met (DI > 0.80, DP < 0.05, EO < 0.05)
- [ ] QMS Policies approved by AI Governance Board
- [ ] SOPs documented and team trained (training log)
- [ ] Pilot successful (success criteria met) OR shadow mode validated
- [ ] Governance Operating Model activated (first Board meeting held)
- [ ] Technical documentation complete (model card, training report)
- [ ] Evidence Log entries for all major decisions

## Typische Herausforderungen

**"Performance vs. Fairness Trade-off"**
→ Unvermeidbar: Fairness constraints kosten meist Performance
→ Business entscheidet: Wie viel Performance-Loss akzeptabel?
→ Dokumentiere trade-off transparent
→ Consider: Ist 1% Accuracy-Loss wirklich problematisch?

**"Board will Policy nicht genehmigen (zu strikt)"**
→ Zeige Sanktionsrisiko (35 Mio € / 7% Umsatz)
→ Benchmark: Was machen Wettbewerber?
→ Pilotiere mit einer Business Unit first

**"Pilot zeigt unerwartete Probleme"**
→ Gut dass Pilot durchgeführt!
→ Root Cause Analysis (5-Why)
→ Update Risk Register
→ Entscheide: Quick Fix oder Redesign?

**"Zu viele SOPs, keiner liest sie"**
→ Priorisiere: Was ist wirklich kritisch?
→ Visualisiere (flowcharts statt text)
→ Training: Hands-on statt Präsentation
→ Checklisten statt 10-Seiten Docs

## Best Practices

1. **Start Simple**: MVP statt Perfect → iterieren
2. **Business Buy-In**: ROI quantifizieren (Sanktionsrisiko vs. Kosten)
3. **Train the Team**: SOPs nur wirksam wenn verstanden
4. **Pilot before Scale**: Unerwartetes passiert immer
5. **Document Decisions**: Especially trade-offs (audit trail!)

## Integration mit Art. 9, 17

**Art. 9 Compliance nach Improve Phase:**
- [ ] Risikomanagementmaßnahmen implementiert
- [ ] Residual Risk dokumentiert und akzeptiert
- [ ] Maßnahmen getestet (Pilot)

**Art. 17 Compliance nach Improve Phase:**
- [ ] QMS Policies dokumentiert
- [ ] Procedures etabliert
- [ ] Nachweise vorhanden (Evidence Log)
- [ ] Post-Market Monitoring vorbereitet (Setup für Control)
