# DMAIC Phase 1: Define – System & Scope Definition

## Ziel
AI-System definieren, Risikoklasse nach Art. 6 bestimmen, QMS-Scope festlegen und Governance etablieren.

## AI Act Bezug
- **Art. 6**: Risikoklassifizierung (Unacceptable, High, Limited, Minimal)
- **Annex III**: Liste der High-Risk AI Systems
- **Art. 17**: QMS Scope Definition

## Schritt-für-Schritt Anleitung

### 1. AI System Charter erstellen

**Purpose:**
- Welches Problem löst das AI-System?
- Welchen Business Value liefert es?
- Wer sind die End Users?

**Use Case Beschreibung:**
- Input: Welche Daten werden verarbeitet?
- Process: Was macht das AI-System?
- Output: Welche Entscheidungen/Empfehlungen/Vorhersagen?

**Risikoklassifizierung nach Art. 6 + Annex III:**

Prüfe gegen Annex III High-Risk Use Cases:
1. Biometric Identification
2. Critical Infrastructure Management
3. Education & Vocational Training
4. Employment & Worker Management
5. Access to Essential Services (Credit, Insurance, etc.)
6. Law Enforcement
7. Migration & Border Control
8. Administration of Justice

**Fragen zur Klassifizierung:**
- Trifft das System Entscheidungen über natürliche Personen?
- Betrifft es Grundrechte (Gleichbehandlung, Privatsphäre, etc.)?
- Hat es signifikanten Einfluss auf Lebenschancen?
- Ist die Entscheidung automatisiert oder hat Human-in-the-Loop?

**Ergebnis:**
→ Risikoklasse: [High-Risk / Limited Risk / Minimal Risk]
→ Begründung: [Mapping zu Annex III]

### 2. SIPOC für AI Lifecycle

**Suppliers:**
- Data Providers (intern/extern)
- Model Vendors (bei Third-Party Models)
- Cloud Infrastructure Provider
- Annotation Services

**Inputs:**
- Training Data (Quellen, Volume, Update-Frequenz)
- Features (welche Attribute)
- Labels (Annotation Quality)
- Historical Production Data (für Retraining)

**Process:**
1. Data Collection & Validation
2. Data Preprocessing & Feature Engineering
3. Model Training
4. Model Validation (Test Set, Cross-Validation)
5. Model Deployment (Staging, Production)
6. Inference & Prediction
7. Monitoring & Feedback Loop
8. Model Retraining

**Outputs:**
- Predictions (Format, Frequency)
- Confidence Scores
- Explanations (SHAP, LIME)
- Alerts (bei Low Confidence)
- Audit Logs

**Customers:**
- Business Users (nutzen Predictions für Entscheidungen)
- End Users (betroffene Personen)
- Regulators (Audits)
- Data Protection Officer

### 3. Stakeholder-Analyse

**Identifiziere alle Stakeholder:**

| Stakeholder | Rolle | Interest | Einfluss | Kommunikation |
|------------|-------|----------|----------|---------------|
| AI Product Owner | Verantwortlich für Business Value | Hoch | Hoch | Wöchentlich |
| Model Risk Manager | Verantwortlich für Risikomanagement (Art. 9) | Hoch | Hoch | Wöchentlich |
| Data Science Team | Entwicklung & Training | Hoch | Mittel | Täglich |
| MLOps Team | Deployment & Monitoring | Hoch | Mittel | Täglich |
| Compliance Officer | AI Act Konformität | Hoch | Hoch | Bi-Weekly |
| Data Protection Officer | GDPR Alignment | Mittel | Hoch | Monatlich |
| Legal Team | Rechtliche Risiken | Mittel | Hoch | Bei Bedarf |
| Betroffene Personen | Empfänger der Entscheidungen | Hoch | Niedrig | Transparent Info |
| Works Council | Arbeitnehmervertretung (bei HR-AI) | Hoch | Hoch | Formale Konsultation |
| Internal Audit | Audit Funktion | Mittel | Mittel | Quartalsweise |

**RACI-Matrix erstellen:**
- Responsible: Wer führt aus?
- Accountable: Wer ist final verantwortlich?
- Consulted: Wer muss konsultiert werden?
- Informed: Wer muss informiert werden?

### 4. Governance-Struktur etablieren

**AI Governance Board:**
- Chair: CTO oder CDO
- Members: AI Product Owner, Risk Manager, Compliance, Legal, DPO
- Frequency: Monatlich
- Entscheidungsbefugnisse:
  - Go/No-Go für neue High-Risk AI Systems
  - Genehmigung Mitigation Strategies
  - Eskalation bei kritischen Incidents
  - Budget für Compliance Maßnahmen

**Roles & Responsibilities:**

**AI Product Owner:**
- Business Case & ROI
- Requirements Definition
- Stakeholder Management
- Go-Live Entscheidung

**Model Risk Manager:**
- Art. 9 Risikomanagement durchführen
- Risk Register pflegen
- Monitoring Plan definieren
- Quarterly Risk Review

**Compliance Officer (AI Act):**
- Interpretation AI Act Requirements
- Gap Analysis
- Audit Coordination
- Regulatory Reporting

**Data Protection Officer:**
- GDPR & AI Act Alignment
- Privacy Impact Assessment
- Data Processing Agreements
- Betroffenenrechte

**Technical Lead / ML Engineer:**
- Model Development
- Technical Documentation
- Testing & Validation
- Incident Investigation

**MLOps Engineer:**
- Deployment Pipeline
- Monitoring Infrastructure
- Drift Detection
- Alert Management

### 5. Business Case & Budget

**Compliance Costs schätzen:**
- Initial Setup:
  - Documentation (Templates, Processes): 20-40 PT
  - Technical Infrastructure (Monitoring): 10-30 PT
  - Training (Team Enablement): 5-10 PT
  
- Recurring Costs:
  - Monitoring & Reporting: 5 PT/Monat
  - Quarterly Reviews: 2 PT/Quartal
  - Annual Re-Validation: 10 PT/Jahr

**Sanktionsrisiko quantifizieren:**
```
Expected Loss = P(Audit) × P(Feststellung|Non-Compliance) × Strafmaß

Beispiel:
P(Audit) = 30%
P(Feststellung) = 80% (bei fehlendem Monitoring)
Strafmaß = 35 Mio € oder 7% Umsatz (max.)

Expected Loss = 0.3 × 0.8 × 35 Mio = 8.4 Mio €
```

**Compliance ROI:**
```
ROI = (Vermiedener Expected Loss - Compliance Costs) / Compliance Costs

Beispiel:
Vermiedener Loss = 8.4 Mio €
Compliance Costs = 200k € (Initial) + 100k €/Jahr
ROI = (8.4 Mio - 300k) / 300k = 2600%
```

### 6. Project Charter finalisieren

**Project Charter Template:**

```
AI ACT COMPLIANCE PROJECT CHARTER

1. PROJECT INFORMATION
   - Project Name:
   - AI System Name:
   - Risikoklasse:
   - Project Start:
   - Target Compliance Date:

2. BUSINESS CASE
   - Problem Statement:
   - AI Act Anforderungen:
   - Sanktionsrisiko:
   - Compliance Budget:

3. SCOPE
   - In Scope: [Welche AI Systems?]
   - Out of Scope: [Was nicht?]
   
4. GOALS & METRICS
   - Compliance Level: [Full Compliance / Partial]
   - Key Milestones:
   - Success Metrics:

5. GOVERNANCE
   - Sponsor:
   - AI Product Owner:
   - Model Risk Manager:
   - Compliance Officer:
   - Steering Committee:

6. RISKS & ASSUMPTIONS
   - Top Risks:
   - Key Assumptions:
```

## Deliverables

✅ **AI System Charter** (Excel)
✅ **SIPOC Diagram** (Excel)
✅ **Stakeholder RACI Matrix** (Excel)
✅ **Governance Operating Model** (Excel)
✅ **Business Case & Budget** (Excel)

## Tollgate Review Kriterien

Zur Freigabe für Measure Phase:

- [ ] Risikoklasse eindeutig bestimmt und dokumentiert
- [ ] Alle relevanten Stakeholder identifiziert
- [ ] RACI-Matrix vollständig und von Stakeholdern akzeptiert
- [ ] AI Governance Board etabliert (erstes Meeting durchgeführt)
- [ ] Budget genehmigt
- [ ] Scope klar definiert (In/Out of Scope)
- [ ] Project Charter von Sponsor unterschrieben

## Typische Herausforderungen

**"Wir wissen nicht, ob wir High-Risk sind"**
→ Systematisch gegen Annex III prüfen
→ Bei Unsicherheit: Legal Opinion einholen
→ Vorsichtsprinzip: Im Zweifel High-Risk annehmen

**"Zu viele Stakeholder wollen mitreden"**
→ RACI klar abgrenzen (Consulted vs. Informed)
→ Governance Board als Final Decision Maker
→ Klare Eskalationswege

**"Budget wird nicht freigegeben"**
→ Sanktionsrisiko quantifizieren (Expected Loss)
→ Reputationsrisiko adressieren
→ Quick Wins identifizieren (Pilot mit einem System)

## Best Practices

1. **Risikoklassifizierung dokumentieren**: Auch wenn "Minimal Risk" → dokumentiere die Begründung
2. **Früh Legal einbinden**: Bei Grenzfällen externe Legal Opinion
3. **Works Council früh informieren**: Bei HR-AI (§ 87 BetrVG)
4. **DPO einbeziehen**: GDPR & AI Act überschneiden sich
5. **Template nutzen**: Nutze Excel Templates für Konsistenz
