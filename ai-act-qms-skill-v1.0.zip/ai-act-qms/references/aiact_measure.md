# DMAIC Phase 2: Measure – Baseline & Performance Metrics

## Ziel
Aktuelle Model Performance messen, Bias identifizieren, Data Quality bewerten und Baseline dokumentieren.

## AI Act Bezug
- **Art. 9**: Baseline für Risikobewertung erforderlich
- **Art. 72**: Baseline als Referenz für Post-Market Monitoring
- **Art. 15**: Data Quality Requirements

## Schritt-für-Schritt Anleitung

### 1. Model Performance Dashboard erstellen

**Zentrale Metriken für Binary Classification:**

#### Confusion Matrix
```
                Predicted
              0         1
Actual  0    TN        FP
        1    FN        TP
```

#### Performance Metrics

**Accuracy** = (TP + TN) / (TP + TN + FP + FN)
- Gesamtanteil korrekter Vorhersagen
- Problem: Missleading bei unbalanced data

**Precision** = TP / (TP + FP)
- Von allen positiven Vorhersagen: Wie viele korrekt?
- Wichtig wenn FP teuer (z.B. Spam Filter)

**Recall (Sensitivity, TPR)** = TP / (TP + FN)
- Von allen echten Positiven: Wie viele erkannt?
- Wichtig wenn FN kritisch (z.B. Krankheitsdiagnose)

**F1-Score** = 2 × (Precision × Recall) / (Precision + Recall)
- Harmonisches Mittel von Precision und Recall
- Gut für unbalanced data

**Specificity (TNR)** = TN / (TN + FP)
- Von allen echten Negativen: Wie viele korrekt erkannt?

**False Positive Rate (FPR)** = FP / (FP + TN) = 1 - Specificity
- Von allen echten Negativen: Wie viele fälschlich als positiv?

**ROC-AUC** (Area Under Receiver Operating Characteristic Curve)
- Misst Trade-off zwischen TPR und FPR
- 1.0 = perfekt, 0.5 = random guessing
- > 0.8 = gut, > 0.9 = excellent

#### Performance by Subgroup

**KRITISCH für AI Act:**  
Metrics müssen für alle relevanten Subgruppen berechnet werden!

```
Beispiel Recruiting AI:

Overall Metrics:
- Accuracy: 0.92
- Precision: 0.88
- Recall: 0.90

By Gender:
- Male: Accuracy=0.93, Precision=0.90, Recall=0.92
- Female: Accuracy=0.89, Precision=0.83, Recall=0.85  ← Gap!
```

**Template:**

| Subgroup | Sample Size | Accuracy | Precision | Recall | F1 | AUC |
|----------|-------------|----------|-----------|--------|----|----- |
| Overall | 10,000 | 0.92 | 0.88 | 0.90 | 0.89 | 0.94 |
| Male | 6,000 | 0.93 | 0.90 | 0.92 | 0.91 | 0.95 |
| Female | 4,000 | 0.89 | 0.83 | 0.85 | 0.84 | 0.91 |
| White | 7,000 | 0.92 | 0.89 | 0.91 | 0.90 | 0.94 |
| Black | 2,000 | 0.88 | 0.82 | 0.84 | 0.83 | 0.90 |
| Age<30 | 2,500 | 0.91 | 0.87 | 0.89 | 0.88 | 0.93 |
| Age 30-50 | 5,500 | 0.92 | 0.88 | 0.90 | 0.89 | 0.94 |
| Age>50 | 2,000 | 0.90 | 0.85 | 0.87 | 0.86 | 0.92 |

**Gap Analysis:**
- Female vs Male: Accuracy Gap = 0.04 (4%)
- Black vs White: Precision Gap = 0.07 (7%)
→ Potential Bias! Investigate in Analyze Phase

### 2. Bias Assessment durchführen

**Fairness Metrics berechnen:**

#### Demographic Parity
Positive Prediction Rates sollten ähnlich sein:

```
P(Ŷ=1|Gender=Female) ≈ P(Ŷ=1|Gender=Male)

Beispiel:
Female: 45% positive predictions
Male: 60% positive predictions
→ Difference: 15% (> 5% threshold) ❌
```

#### Equalized Odds
TPR und FPR sollten ähnlich sein:

```
TPR_Female ≈ TPR_Male
FPR_Female ≈ FPR_Male

Beispiel:
TPR_Female: 0.85
TPR_Male: 0.92
→ Difference: 0.07 (> 5% threshold) ❌
```

#### Disparate Impact Ratio
Ratio sollte >= 0.80 (80% Rule):

```
Ratio = P(Ŷ=1|Unprivileged) / P(Ŷ=1|Privileged)

Beispiel:
Ratio = 0.45 / 0.60 = 0.75
→ < 0.80 threshold ❌
```

**Dokumentation:**

| Protected Attribute | Metric | Value | Threshold | Status | Action |
|---------------------|--------|-------|-----------|--------|--------|
| Gender | Demographic Parity Diff | 0.15 | 0.05 | ❌ | Mitigate |
| Gender | Equalized Odds Diff | 0.07 | 0.05 | ❌ | Mitigate |
| Gender | Disparate Impact | 0.75 | 0.80 | ❌ | Mitigate |
| Race | Demographic Parity Diff | 0.08 | 0.05 | ⚠️ | Investigate |
| Age | Disparate Impact | 0.82 | 0.80 | ✅ | Monitor |

### 3. Data Quality Assessment

#### Completeness (Vollständigkeit)
Anteil fehlender Werte pro Feature:

```python
missing_rates = data.isnull().mean() * 100

Beispiel:
age: 2.3% missing ✅
income: 8.5% missing ⚠️
education: 15.2% missing ❌
```

**Threshold:**
- < 5%: Acceptable
- 5-10%: Investigate
- > 10%: Critical

**Action bei > 10%:**
1. Understand missingness pattern (MCAR, MAR, MNAR)
2. If systematic → potential bias
3. Imputation strategy or feature exclusion

#### Accuracy (Genauigkeit)
Anteil korrekter Werte:

**Methods:**
- Manual audit (sample n=100-500)
- Cross-validation with trusted source
- Logical consistency checks

**Example:**
```
Age range check: age < 18 or age > 100 → flag
Income consistency: income < minimum_wage → flag
Education-Age check: PhD at age 20 → flag
```

#### Consistency (Konsistenz)
Gleiche Information in verschiedenen Quellen:

```
Source A: customer_age = 45
Source B: customer_dob = 1978 → age = 46
→ Inconsistency detected
```

#### Representativeness (Repräsentativität)
Training Data vs. Population Distribution:

```
Population: 51% Female, 49% Male
Training: 40% Female, 60% Male
→ Sampling Bias! ❌
```

**Chi-Square Test für Kategorien:**
```python
from scipy.stats import chisquare

observed = [400, 600]  # Female, Male in Training
expected = [510, 490]  # Based on Population
chi2, p_value = chisquare(observed, expected)

if p_value < 0.05:
    print("Significant difference from population")
```

#### Outlier Detection
IQR Method für numerische Features:

```python
Q1 = data['income'].quantile(0.25)
Q3 = data['income'].quantile(0.75)
IQR = Q3 - Q1

outliers = (data['income'] < Q1 - 1.5*IQR) | (data['income'] > Q3 + 1.5*IQR)
outlier_rate = outliers.mean() * 100

Beispiel:
Income outliers: 3.2% ✅
Age outliers: 0.8% ✅
Credit_score outliers: 12.5% ⚠️ (investigate)
```

**Data Quality Score:**
```
DQ Score = (Completeness + Accuracy + Consistency + Representativeness) / 4

Beispiel:
Completeness: 92%
Accuracy: 88%
Consistency: 95%
Representativeness: 75%
→ DQ Score: 87.5%
```

**Threshold:**
- > 90%: Excellent
- 80-90%: Good
- 70-80%: Acceptable (monitor)
- < 70%: Critical (do not proceed)

### 4. Measurement System Analysis (MSA)

**Für Input Features die gemessen/annotiert werden:**

#### Gage R&R für kontinuierliche Features
Wenn Features von Menschen gemessen werden (z.B. CV-Scoring):

```
Repeatability: Gleicher Operator, gleiches Item → wie konsistent?
Reproducibility: Verschiedene Operatoren, gleiches Item → wie konsistent?

Acceptable:
- Total Gage R&R < 10%: Excellent
- Total Gage R&R 10-30%: Acceptable
- Total Gage R&R > 30%: Unacceptable
```

#### Annotation Agreement für Labels
Wenn Labels von Menschen annotiert werden:

**Cohen's Kappa (2 Annotators):**
```
κ < 0.40: Poor agreement
κ 0.40-0.60: Moderate
κ 0.60-0.80: Substantial
κ > 0.80: Excellent
```

**Fleiss' Kappa (>2 Annotators):**
Gleiche Interpretation wie Cohen's Kappa

**Action bei κ < 0.60:**
1. Annotation Guidelines verbessern
2. Annotator Training
3. Schwierige Cases mit Expert Review
4. ggf. Third Annotator für Tie-Breaking

### 5. Process Mapping – AI Value Stream

**AI Lifecycle Mapping:**

```
[Data Collection] → [Data Validation] → [Preprocessing] → [Feature Engineering]
  ↓ 2h/day            ↓ 30min/day         ↓ 1h/day         ↓ 3h/day
  
→ [Model Training] → [Validation] → [Deployment] → [Monitoring] → [Retraining]
  ↓ 4h/run          ↓ 2h           ↓ 30min        ↓ daily       ↓ monthly
  
Bottlenecks:
- Feature Engineering: 3h/day (manual)
- Model Training: 4h/run (computational)
```

**Cycle Time Metrics:**

| Stage | Average Time | Lead Time | Bottleneck? |
|-------|--------------|-----------|-------------|
| Data Collection | 2h/day | - | No |
| Data Validation | 30min/day | - | No |
| Preprocessing | 1h/day | - | No |
| Feature Engineering | 3h/day | - | **Yes** |
| Model Training | 4h/run | - | **Yes** |
| Validation | 2h | - | No |
| Deployment | 30min | - | No |
| **Total Cycle Time** | **~13h** | **2-3 days** | - |

**Handoffs & Responsibilities:**

| Handoff | From | To | Documentation | Issues |
|---------|------|-----|---------------|--------|
| Raw Data → Validated Data | Data Eng | ML Eng | Data Schema | Format changes |
| Features → Model | ML Eng | ML Eng | Feature Spec | Versioning |
| Model → Deployment | ML Eng | MLOps | Model Card | API mismatches |
| Monitoring Alerts → Investigation | MLOps | ML Eng | Alert Log | Response time |

**Waste Analysis (Lean TIMWOODS):**

- **Transport**: Data movement zwischen Systemen → 15min/day
- **Inventory**: Backlog von Feature Requests → 20 items
- **Motion**: Switching zwischen Tools → 30min/day
- **Waiting**: Auf Training Results → 4h/run
- **Overprocessing**: Doppelte Validierung → 20min/day
- **Overproduction**: Unused Features → 30% nicht genutzt
- **Defects**: Failed Deployments → 5% Rollback Rate
- **Skills**: Manual Feature Engineering → könnte automatisiert werden

### 6. Baseline Dokumentation

**Baseline Metrics Report Template:**

```
BASELINE METRICS REPORT – [AI System Name]

Document Control:
- Version: 1.0
- Date: [Datum]
- Baseline Period: [Start] - [End]
- Data Size: [n samples]
- Owner: [ML Engineer]

1. MODEL PERFORMANCE (Overall)
   - Accuracy: 0.92 ± 0.01
   - Precision: 0.88 ± 0.02
   - Recall: 0.90 ± 0.01
   - F1-Score: 0.89 ± 0.01
   - AUC-ROC: 0.94 ± 0.01

2. PERFORMANCE BY SUBGROUP
   [siehe Tabelle oben]
   
   Key Findings:
   - Female candidates: 4% accuracy gap
   - Black candidates: 7% precision gap
   → Requires mitigation (Improve Phase)

3. FAIRNESS METRICS
   [siehe Bias Assessment Tabelle]
   
   Critical Issues:
   - Gender Disparate Impact: 0.75 (< 0.80) ❌
   - Action: Implement fairness constraints

4. DATA QUALITY
   - Overall DQ Score: 87.5%
   - Completeness: 92%
   - Accuracy: 88%
   - Consistency: 95%
   - Representativeness: 75% (⚠️ sampling bias)

5. MEASUREMENT SYSTEM
   - Label Agreement (Cohen's κ): 0.78 (Substantial)
   - Action: Acceptable, continue monitoring

6. PROCESS METRICS
   - Total Cycle Time: 13h (2-3 days)
   - Bottlenecks: Feature Engineering (3h), Training (4h)
   - Waste: 30% unused features
   - Action: Feature selection, automation

7. BASELINE TARGETS FOR MONITORING
   
   Performance (Art. 72 Control Phase):
   - Accuracy: Target > 0.92, Warning < 0.90, Alert < 0.88
   - Precision: Target > 0.88, Warning < 0.86, Alert < 0.83
   - Recall: Target > 0.90, Warning < 0.87, Alert < 0.84
   
   Fairness (Art. 9 Risk Monitoring):
   - Disparate Impact: Target > 0.80, Warning < 0.80, Alert < 0.75
   - Demographic Parity: Target < 0.05, Warning > 0.05, Alert > 0.10
```

## Deliverables

✅ **Model Performance Dashboard** (Python Script + Report)
✅ **Bias Assessment Report** (Excel)
✅ **Data Quality Scorecard** (Excel)
✅ **MSA Report** (Excel) - wenn applicable
✅ **AI Value Stream Map** (PowerPoint/Visio)
✅ **Baseline Metrics Report** (Word/PDF)

## Tollgate Review Kriterien

Zur Freigabe für Analyze Phase:

- [ ] Baseline Performance für alle relevanten Subgruppen dokumentiert
- [ ] Bias Metrics für alle Protected Attributes berechnet
- [ ] Data Quality Score > 70% (sonst STOP)
- [ ] Gaps und Issues identifiziert und dokumentiert
- [ ] Measurement System acceptable (κ > 0.60 für Labels)
- [ ] Process Bottlenecks identifiziert
- [ ] Monitoring Targets definiert (für Control Phase)

## Typische Herausforderungen

**"Data Quality Score < 70%"**
→ STOP: Do NOT proceed to training
→ Fix data quality issues first
→ Root cause: Upstream data processes

**"Kein Zugriff auf Protected Attributes"**
→ Legal/Privacy Issue
→ Proxy-Variables nutzen (z.B. ZIP code für race)
→ Caveat: Proxy nicht perfekt, dokumentieren

**"Label Agreement κ < 0.40"**
→ Annotation Guidelines unclear
→ Training erforderlich
→ Expert Review für schwierige Cases

**"Huge Performance Gap zwischen Subgroups"**
→ Nicht überraschend bei historical bias
→ Dokumentieren für Analyze Phase
→ Business entscheidet: Akzeptabel oder Mitigation?

## Best Practices

1. **Stratified Sampling**: Bei Subgroup Analysis auf ausreichende Sample Size achten (min. n=100 per group)
2. **Confidence Intervals**: Metrics mit ± angeben (Bootstrap für CI)
3. **Multiple Testing**: Bei vielen Subgroups → Bonferroni Correction
4. **Visualisierung**: Performance Gaps visualisieren (heatmaps, bar charts)
5. **Early Warning**: Bereits in Measure Phase kritische Gaps eskalieren

## Integration mit Art. 9, 72

**Art. 9 (Risikomanagement):**
- Baseline = Starting Point für Risk Assessment
- Performance Gaps = Potenzielle Risiken

**Art. 72 (Monitoring):**
- Baseline = Reference für Drift Detection
- Monitoring Targets aus Baseline ableiten

## Tools & Scripts

Nutze folgende Scripts:
```python
from model_performance_metrics import calculate_comprehensive_metrics
from bias_detection import BiasDetector
from data_quality_assessment import DataQualityScorecard
```

Siehe `/scripts/` Verzeichnis für Details.
