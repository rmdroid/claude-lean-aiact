# DMAIC Phase 5: Control – Post-Market Monitoring (Art. 72)

## Ziel
Kontinuierliches Monitoring etablieren, Drift Detection automatisieren, Eskalationsprozesse definieren und Auditfähigkeit sicherstellen.

## AI Act Bezug

**Art. 72 - Post-Market Monitoring:**
> Anbieter legen einen Post-Market-Monitoring-Plan fest. Der Plan wird systematisch durchgeführt und beinhaltet die Erfassung und Auswertung von Daten zu Erfahrungen mit dem Hochrisiko-KI-System über dessen gesamte Lebensdauer.

**Anforderungen:**
1. Systematische Erfassung von Performance-Daten
2. Auswertungsverfahren etablieren
3. Identifikation von Risiken und Nebenwirkungen
4. Festlegung von Verantwortlichkeiten
5. Eskalationsprozesse bei Abweichungen

## Schritt-für-Schritt Anleitung

### 1. Post-Market Monitoring Plan erstellen

**Template:**

```
POST-MARKET MONITORING PLAN – [AI System Name]

Document Control:
- Version: 1.0
- Date: [Datum]
- Owner: [Model Risk Manager]
- Review Frequency: Quarterly
- Last Update: [Datum]

1. MONITORING SCOPE
   - AI System: [Name]
   - Risikoklasse: High-Risk
   - Deployment Date: [Datum]
   - Monitoring Start: [Datum]

2. WAS WIRD ÜBERWACHT?

   2.1 Model Performance Metrics
   
   | Metric | Target | Warning Threshold | Alert Threshold | Critical Threshold | Frequency | Owner |
   |--------|--------|-------------------|-----------------|-------------------|-----------|-------|
   | Accuracy | > 92% | < 90% | < 88% | < 85% | Weekly | ML Engineer |
   | Precision | > 85% | < 83% | < 80% | < 75% | Weekly | ML Engineer |
   | Recall | > 88% | < 85% | < 82% | < 78% | Weekly | ML Engineer |
   | F1-Score | > 86% | < 84% | < 81% | < 77% | Weekly | ML Engineer |
   | AUC-ROC | > 0.90 | < 0.88 | < 0.85 | < 0.80 | Weekly | ML Engineer |
   
   2.2 Fairness & Bias Metrics
   
   | Metric | Target | Warning | Alert | Critical | Frequency | Owner |
   |--------|--------|---------|-------|----------|-----------|-------|
   | Demographic Parity Diff | < 0.05 | > 0.07 | > 0.10 | > 0.15 | Monthly | Risk Manager |
   | Equalized Odds Diff | < 0.05 | > 0.07 | > 0.10 | > 0.15 | Monthly | Risk Manager |
   | Disparate Impact Ratio | > 0.80 | < 0.75 | < 0.70 | < 0.65 | Monthly | Risk Manager |
   
   2.3 Data Drift Metrics
   
   | Metric | Target | Warning | Alert | Critical | Frequency | Owner |
   |--------|--------|---------|-------|----------|-----------|-------|
   | PSI (Population Stability Index) | < 0.10 | 0.10-0.25 | > 0.25 | > 0.50 | Daily | MLOps |
   | KS Statistic | < 0.10 | 0.10-0.20 | > 0.20 | > 0.30 | Daily | MLOps |
   
   2.4 Prediction Drift Metrics
   
   | Metric | Target | Warning | Alert | Critical | Frequency | Owner |
   |--------|--------|---------|-------|----------|-----------|-------|
   | Prediction Mean Shift | < 5% | 5-10% | > 10% | > 20% | Weekly | MLOps |
   | Prediction Std Dev Change | < 10% | 10-20% | > 20% | > 30% | Weekly | MLOps |
   
   2.5 User Feedback & Complaints
   
   | Source | Target | Warning | Alert | Frequency | Owner |
   |--------|--------|---------|-------|-----------|-------|
   | User Complaints | < 5/month | 5-10 | > 10 | Daily | Product Owner |
   | False Positive Reports | < 2% | 2-5% | > 5% | Weekly | Product Owner |
   | False Negative Reports | < 1% | 1-3% | > 3% | Weekly | Product Owner |

3. WER IST VERANTWORTLICH?

   3.1 Roles & Responsibilities
   
   | Role | Responsibility | Accountability |
   |------|---------------|----------------|
   | Model Risk Manager | Gesamtverantwortung Monitoring Plan | Sign-off on Escalations |
   | ML Engineer | Performance Metrics Tracking | Weekly Reports |
   | MLOps Engineer | Drift Detection & Alerting | Daily Monitoring |
   | Product Owner | User Feedback Collection | User Communication |
   | Compliance Officer | Audit Trail & Evidence Logs | Quarterly Reviews |
   | AI Governance Board | Eskalation Decisions | Go/No-Go Decisions |
   
   3.2 RACI Matrix
   
   | Task | Risk Mgr | ML Eng | MLOps | Product | Compliance | Board |
   |------|----------|--------|-------|---------|------------|-------|
   | Weekly Performance Review | A | R | C | I | I | I |
   | Monthly Bias Review | A | C | I | C | R | I |
   | Daily Drift Monitoring | I | I | R/A | I | I | I |
   | Incident Investigation | A | R | R | C | C | I |
   | Escalation Decision | I | I | I | C | C | R/A |

4. SCHWELLWERTE & ESKALATION

   4.1 Eskalationsstufen
   
   **Level 1 - Warning (Gelb):**
   - Trigger: Warning Threshold überschritten
   - Action: Monitoring intensivieren
   - Owner: ML Engineer / MLOps
   - Response Time: 5 Werktage Root Cause Analysis
   - Escalation: Keine (außer nach 2 Wochen ohne Verbesserung)
   
   **Level 2 - Alert (Orange):**
   - Trigger: Alert Threshold überschritten
   - Action: Mitigation Plan erstellen
   - Owner: Model Risk Manager
   - Response Time: 48 Stunden Mitigation Plan
   - Escalation: An AI Governance Board (Info)
   - Documentation: Incident Report erforderlich
   
   **Level 3 - Critical (Rot):**
   - Trigger: Critical Threshold überschriffen
   - Action: Emergency Response + ggf. Model Deactivation
   - Owner: AI Governance Board
   - Response Time: 24 Stunden Emergency Meeting
   - Escalation: Management Board + Legal
   - Documentation: Full Incident Report + Corrective Actions

   4.2 Eskalationspfade
   
   ```
   Warning → ML Engineer investigates → If no improvement after 2 weeks → Alert
   
   Alert → Risk Manager creates Mitigation Plan → 48h → Board reviews → Approve/Escalate
   
   Critical → Immediate Board Meeting → 24h → Decision: Deactivate/Mitigate → Management informed
   ```

5. MONITORING INFRASTRUCTURE

   5.1 Tools & Dashboards
   - Performance Dashboard: [Tool, URL]
   - Bias Monitoring: [Tool, URL]
   - Drift Detection: [Tool, URL]
   - Alerting System: [Tool, URL]
   
   5.2 Data Collection
   - Prediction Logs: [Location, Retention]
   - Feature Logs: [Location, Retention]
   - Feedback Logs: [Location, Retention]
   - Audit Logs: [Location, Retention]

6. REVIEW & UPDATE SCHEDULE

   | Review Type | Frequency | Participants | Deliverable |
   |-------------|-----------|--------------|-------------|
   | Weekly Performance Review | Weekly | ML Eng, MLOps | Metrics Report |
   | Monthly Bias Review | Monthly | Risk Mgr, ML Eng, Compliance | Fairness Report |
   | Quarterly Risk Review | Quarterly | Risk Mgr, Board | Updated Risk Register |
   | Annual Model Re-Validation | Yearly | All Stakeholders | Re-Validation Report |
```

### 2. Control Charts für AI

**Nutze Statistical Process Control (SPC) für AI Metrics:**

#### X-bar / R Chart für Accuracy

```python
from ai_control_charts import xbar_r_chart

# Weekly Accuracy Samples (Subgroup = Daily, n=7)
accuracy_data = [
    [0.92, 0.91, 0.93, 0.92, 0.91, 0.92, 0.93],  # Week 1
    [0.91, 0.90, 0.92, 0.91, 0.90, 0.91, 0.92],  # Week 2
    [0.89, 0.88, 0.90, 0.89, 0.88, 0.89, 0.90],  # Week 3 (Drift detected)
]

xbar_r_chart(
    data=accuracy_data,
    target=0.92,
    spec_limits=(0.85, 1.0),
    title="Model Accuracy Control Chart"
)
```

**Western Electric Rules für Out-of-Control Detection:**
- Rule 1: One point > 3σ from center line
- Rule 2: Two out of three consecutive points > 2σ
- Rule 3: Four out of five consecutive points > 1σ
- Rule 4: Eight consecutive points on same side of center

#### I-MR Chart für Individual Metrics

```python
from ai_control_charts import i_mr_chart

# Individual Precision values (daily)
precision_data = [0.85, 0.86, 0.84, 0.85, 0.83, 0.82, 0.81, 0.80]

i_mr_chart(
    data=precision_data,
    target=0.85,
    spec_limits=(0.75, 1.0),
    title="Precision Individual Chart"
)
```

#### p-Chart für Error Rate by Subgroup

```python
from ai_control_charts import p_chart

# Error rates for protected groups
error_rates = {
    'Female': [0.08, 0.09, 0.08, 0.10, 0.11, 0.12],  # Increasing trend
    'Male': [0.07, 0.07, 0.08, 0.07, 0.08, 0.07],    # Stable
}

p_chart(
    data=error_rates,
    title="Error Rate by Gender"
)
```

#### EWMA für Drift Detection

```python
from ai_control_charts import ewma_chart

# Feature drift (PSI values)
psi_values = [0.05, 0.06, 0.08, 0.12, 0.18, 0.25, 0.30]

ewma_chart(
    data=psi_values,
    lambda_param=0.2,  # Weight for recent observations
    control_limit=0.25,
    title="PSI Drift Detection (EWMA)"
)
```

### 3. Evidence Logs für Audits

**Template:**

```
EVIDENCE LOG – [AI System Name]

Purpose: Audit Trail für AI Act Compliance (Art. 9, 17, 72)

| Evidence ID | Date | Type | Description | AI Act Article | Location | Owner | Status |
|-------------|------|------|-------------|----------------|----------|-------|--------|
| EV-001 | 2024-12-01 | Risk Assessment | Initial AI-FMEA | Art. 9 | /docs/fmea_v1.xlsx | Risk Mgr | Final |
| EV-002 | 2024-12-15 | QMS Doc | Model Development SOP | Art. 17 | /docs/sop_dev_v1.pdf | Compliance | Final |
| EV-003 | 2025-01-05 | Monitoring Plan | Post-Market Monitoring Plan v1.0 | Art. 72 | /docs/monitoring_plan.pdf | Risk Mgr | Final |
| EV-004 | 2025-01-12 | Performance Report | Weekly Accuracy Report W2 | Art. 72 | /reports/2025/W2.pdf | ML Eng | Final |
| EV-005 | 2025-01-20 | Bias Report | Monthly Fairness Metrics Jan 2025 | Art. 9 | /reports/bias/2025-01.pdf | Risk Mgr | Final |
| EV-006 | 2025-01-22 | Incident Report | Accuracy Drop Alert - Week 3 | Art. 72 | /incidents/INC-001.pdf | Risk Mgr | Draft |
| EV-007 | 2025-01-25 | Mitigation Plan | Re-training Plan Q1 2025 | Art. 9 | /docs/retrain_plan_q1.pdf | ML Eng | Final |
```

**Evidence Types:**
- Risk Assessments (FMEA, Risk Register)
- QMS Documentation (Policies, SOPs)
- Monitoring Reports (Performance, Bias, Drift)
- Incident Reports & Corrective Actions
- Validation Reports (Model Testing)
- Training Records (Team Enablement)
- Board Meeting Minutes (Governance Decisions)

### 4. Standard Operating Procedures (SOPs)

#### SOP: Model Drift Response

```
SOP-AI-001: Model Drift Response Procedure

1. PURPOSE
   Describe response to model drift detection (PSI > 0.25 or performance drop > 5%)

2. SCOPE
   All High-Risk AI Systems in Production

3. RESPONSIBILITIES
   - MLOps Engineer: Drift Detection & Initial Investigation
   - ML Engineer: Root Cause Analysis & Re-training
   - Model Risk Manager: Approval of Mitigation Plan
   - AI Governance Board: Go/No-Go Decision

4. PROCEDURE

   4.1 Drift Detection (Automated)
       - Daily PSI calculation for all features
       - Weekly performance metric tracking
       - Alert triggered if threshold exceeded

   4.2 Initial Investigation (MLOps, 24h)
       - Verify alert (false positive check)
       - Identify drifted features
       - Assess impact on predictions
       - Document findings in Incident Report

   4.3 Root Cause Analysis (ML Engineer, 48h)
       - Analyze data distribution changes
       - Identify external factors (market changes, seasonality)
       - Assess if drift is temporary or permanent
       - Recommend: Monitor / Retrain / Deactivate

   4.4 Mitigation Plan (ML Engineer, 72h)
       - Option A: Temporary Monitoring (if drift < 0.30)
       - Option B: Accelerated Retraining (if drift > 0.30)
       - Option C: Model Deactivation (if critical performance impact)
       - Include timeline, resources, risk assessment

   4.5 Approval (Risk Manager, 24h)
       - Review Mitigation Plan
       - Assess residual risk
       - Approve or escalate to Board

   4.6 Implementation & Validation
       - Execute approved plan
       - Validate new model before deployment
       - Update Evidence Log

   4.7 Post-Mortem (within 2 weeks)
       - Document lessons learned
       - Update Risk Register if new risk identified
       - Update Monitoring Plan if thresholds need adjustment

5. RECORDS
   - Incident Report (Template: INC-Template.docx)
   - Root Cause Analysis (Template: RCA-Template.xlsx)
   - Mitigation Plan (Template: MIT-Template.docx)
   - Evidence Log Entry

6. REFERENCES
   - Art. 72 EU AI Act
   - Monitoring Plan
```

#### SOP: Bias Incident Handling

```
SOP-AI-002: Bias Incident Response Procedure

1. PURPOSE
   Describe response to bias incidents (fairness metric violations or user complaints)

2. SCOPE
   All High-Risk AI Systems affecting natural persons

3. PROCEDURE

   3.1 Incident Detection
       - Monthly fairness metrics review
       - User complaint about discriminatory decision
       - Media/regulatory inquiry
       - Internal audit finding

   3.2 Severity Assessment (Risk Manager, 24h)
       - Level 1: Fairness metric slightly out of range (0.75 < DI < 0.80)
       - Level 2: Significant bias detected (DI < 0.75) or multiple complaints
       - Level 3: Systematic discrimination or fundamental rights violation

   3.3 Immediate Actions
       - Level 1: Intensified monitoring, no operational change
       - Level 2: Human review for affected decisions, investigate root cause
       - Level 3: IMMEDIATE model deactivation, full investigation

   3.4 Investigation (Risk Manager + ML Engineer, 5 days)
       - Identify affected population size
       - Quantify harm (false negatives for protected group)
       - Root cause: Data bias, model bias, deployment bias?
       - Document fundamental rights impact

   3.5 Remediation Plan
       - Technical: Re-sampling, fairness constraints, re-training
       - Process: Enhanced human oversight, policy changes
       - Communication: Inform affected users if required
       - Compensation: If harm occurred

   3.6 Regulatory Reporting
       - If serious incident (Art. 73 AI Act): Report to authority within 15 days
       - GDPR: Coordinate with DPO if personal data involved

   3.7 Prevention
       - Update training data collection
       - Enhance fairness testing in validation
       - Update Risk Register

4. ESCALATION
   - Level 1 → Risk Manager
   - Level 2 → AI Governance Board (Info)
   - Level 3 → AI Governance Board (Emergency) + Management Board + Legal

5. DOCUMENTATION
   - Bias Incident Report
   - Investigation Report
   - Remediation Plan
   - Regulatory Report (if applicable)
   - Evidence Log Entries
```

### 5. Continuous Improvement Loop

**PDCA for AI Systems:**

```
Plan → Monitoring Plan, Risk Register
Do → Execute Monitoring, Collect Data
Check → Review Metrics, Detect Drift/Bias
Act → Retrain, Update SOPs, Learn

Quarterly Cycle:
Q1: Execute → Collect Learnings
Q2: Review Learnings → Update Plans
Q3: Implement Updates → Validate
Q4: Year-End Review → Strategic Adjustments
```

## Deliverables

✅ **Post-Market Monitoring Plan (Art. 72 Konform)** (Word/PDF)
✅ **Control Charts Dashboard** (Python Scripts + Plots)
✅ **Evidence Log** (Excel)
✅ **SOPs: Drift Response, Bias Handling, Quarterly Review** (Word/PDF)
✅ **Automated Alerting System** (Code + Config)

## Tollgate Review Kriterien

Zur Freigabe für Production:

- [ ] Monitoring Plan vollständig und von Board genehmigt
- [ ] Alle Schwellwerte definiert und validiert
- [ ] Verantwortlichkeiten RACI-Matrix erstellt
- [ ] Eskalationspfade getestet (dry run)
- [ ] Control Charts implementiert und validiert
- [ ] Evidence Log System etabliert
- [ ] SOPs dokumentiert und Team trainiert
- [ ] Alerting System funktioniert (tested)
- [ ] Quarterly Review Schedule festgelegt

## Typische Herausforderungen

**"Zu viele False Alerts"**
→ Schwellwerte adjustieren basierend auf historical data
→ Multi-Level Alerting (Warning vs. Critical)
→ Alert Fatigue vermeiden durch Aggregation

**"Team hat keine Zeit für wöchentliche Reviews"**
→ Automatisierung maximieren (dashboards)
→ Exception-based Reviews (nur bei Alerts)
→ Monatliche Consolidated Reports

**"Schwierig Baseline für Fairness Metrics"**
→ Nutze industry benchmarks oder regulatory guidance
→ Konservative Schwellwerte (0.80 für Disparate Impact)
→ Update basierend auf real-world data

## Best Practices

1. **Automate Everything Possible**: Dashboards, Alerts, Reports
2. **Balance Sensitivity vs. Alert Fatigue**: Multi-level thresholds
3. **Test Escalation Paths**: Dry runs vor Go-Live
4. **Version Control für Plans**: Monitoring Plan ist living document
5. **Integrate with Existing Systems**: ITSM, SIEM, BI Tools
6. **Regular Training**: Quarterly refreshers for team on SOPs

## Integration mit Art. 72 AI Act

**Art. 72 Compliance Checklist nach Control Phase:**

- [ ] **Systematische Erfassung**: Automated data collection läuft
- [ ] **Auswertungsverfahren**: Control charts & reviews etabliert
- [ ] **Identifikation Risiken**: Drift/Bias detection funktioniert
- [ ] **Verantwortlichkeiten**: RACI Matrix kommuniziert
- [ ] **Eskalation bei Abweichungen**: SOPs dokumentiert, team trained

## Audit Readiness Finale

**Vor dem Audit sicherstellen:**

1. **6 Monate Monitoring Data verfügbar**
   - Performance Reports
   - Bias Reports
   - Drift Detection Logs
   - User Feedback

2. **Evidence Log vollständig**
   - Alle Incidents dokumentiert
   - Mitigation Plans vorhanden
   - Governance Decisions nachvollziehbar

3. **SOPs angewendet**
   - Incident Handling gemäß SOP
   - Quarterly Reviews durchgeführt
   - Lessons Learned dokumentiert

4. **Team kann Fragen beantworten**
   - Wer ist verantwortlich für was?
   - Was passiert bei Alert?
   - Wie oft wird reviewed?
   - Welche Schwellwerte gelten?
