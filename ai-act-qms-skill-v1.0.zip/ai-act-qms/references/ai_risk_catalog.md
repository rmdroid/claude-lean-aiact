# AI Risk Catalog
**Comprehensive catalog of AI-specific risks for EU AI Act compliance**

Version: 1.0  
Last Updated: December 2024

## Purpose

This catalog provides a structured taxonomy of risks specific to AI systems to support:
- Art. 9 risk identification and assessment
- AI-FMEA workshops
- Risk Register population
- Mitigation planning

## Risk Categories

### 1. Model Performance Risks

#### 1.1 Insufficient Accuracy
- **Description**: Model fails to achieve acceptable prediction accuracy
- **Causes**: Inadequate training data, wrong algorithm, insufficient features
- **Impact**: Wrong decisions affecting individuals, business losses
- **Severity**: 6-8 (depending on use case)
- **Detection**: Performance monitoring, validation testing
- **Mitigation**: Model selection, hyperparameter tuning, feature engineering

#### 1.2 Low Precision (High False Positive Rate)
- **Description**: Model predicts too many false positives
- **Causes**: Unbalanced data, wrong decision threshold, overfitting
- **Impact**: Wasted resources, user frustration, opportunity costs
- **Example**: Credit scoring denying good customers
- **Severity**: 5-7
- **Detection**: Confusion matrix analysis, precision monitoring
- **Mitigation**: Threshold optimization, class rebalancing, cost-sensitive learning

#### 1.3 Low Recall (High False Negative Rate)
- **Description**: Model misses too many true positives
- **Causes**: Unbalanced data, conservative threshold, insufficient training
- **Impact**: Missed opportunities, safety risks, regulatory violations
- **Example**: Fraud detection missing actual fraud
- **Severity**: 7-9 (especially in safety-critical applications)
- **Detection**: Recall monitoring, false negative analysis
- **Mitigation**: Threshold adjustment, oversampling minority class, ensemble methods

#### 1.4 Overfitting
- **Description**: Model performs well on training data but poorly on new data
- **Causes**: Too complex model, too little training data, data leakage
- **Impact**: Performance degradation in production, unreliable predictions
- **Severity**: 6-7
- **Detection**: Train-test performance gap, cross-validation
- **Mitigation**: Regularization, cross-validation, simpler model architecture

#### 1.5 Underfitting
- **Description**: Model too simple to capture underlying patterns
- **Causes**: Insufficient model complexity, missing features, wrong algorithm
- **Impact**: Poor performance, missed business value
- **Severity**: 5-6
- **Detection**: Low training accuracy, simple decision boundaries
- **Mitigation**: More complex model, feature engineering, algorithm change

### 2. Fairness & Bias Risks

#### 2.1 Historical Bias
- **Description**: Training data reflects historical discrimination
- **Causes**: Societal biases in historical data collection
- **Impact**: Perpetuating or amplifying existing discrimination
- **Example**: Hiring AI trained on historical male-dominated hiring
- **Severity**: 8-10 (fundamental rights violation)
- **Detection**: Demographic parity analysis, disparate impact testing
- **Mitigation**: Data rebalancing, fairness constraints, adversarial debiasing

#### 2.2 Representation Bias
- **Description**: Certain groups underrepresented in training data
- **Causes**: Sampling methodology, access barriers, historical exclusion
- **Impact**: Poor performance for underrepresented groups
- **Example**: Face recognition failing for darker skin tones
- **Severity**: 7-9
- **Detection**: Subgroup performance analysis, data distribution checks
- **Mitigation**: Stratified sampling, data augmentation, targeted data collection

#### 2.3 Measurement Bias
- **Description**: Features measured differently or with different quality across groups
- **Causes**: Inconsistent measurement instruments, proxy variables
- **Impact**: Systematic errors for certain groups
- **Example**: Credit score less accurate for immigrants
- **Severity**: 7-8
- **Detection**: Measurement System Analysis per subgroup, feature correlation analysis
- **Mitigation**: Standardized measurement procedures, calibration per group

#### 2.4 Aggregation Bias
- **Description**: One-size-fits-all model for diverse populations
- **Causes**: Assuming homogeneity, computational convenience
- **Impact**: Suboptimal performance for minority groups
- **Example**: Medical diagnosis model optimized for average patient
- **Severity**: 7-9 (especially in healthcare)
- **Detection**: Subgroup performance analysis, model complexity analysis
- **Mitigation**: Separate models per group, interaction features, personalization

#### 2.5 Evaluation Bias
- **Description**: Test set not representative of production population
- **Causes**: Non-random test set selection, temporal bias
- **Impact**: Overestimated performance, unforeseen failures
- **Severity**: 6-7
- **Detection**: Population distribution comparison (chi-square)
- **Mitigation**: Stratified test set, continuous monitoring in production

#### 2.6 Deployment Bias
- **Description**: Model used differently than intended or for different populations
- **Causes**: Scope creep, lack of documentation, misunderstanding
- **Impact**: Poor performance, unfair outcomes
- **Example**: Resume screener trained on tech jobs used for all positions
- **Severity**: 6-8
- **Detection**: Use case monitoring, user feedback analysis
- **Mitigation**: Clear scope definition, user training, access controls

### 3. Data Quality Risks

#### 3.1 Incomplete Data (Missing Values)
- **Description**: Systematic missing values in features
- **Causes**: Collection failures, privacy restrictions, data integration issues
- **Impact**: Biased predictions, reduced performance
- **Severity**: 5-7
- **Detection**: Missing value rate monitoring, MCAR/MAR/MNAR tests
- **Mitigation**: Imputation strategies, missingness indicators, data collection improvement

#### 3.2 Inaccurate Data (Label Noise)
- **Description**: Training labels contain errors
- **Causes**: Annotation errors, outdated data, measurement errors
- **Impact**: Model learns wrong patterns, poor generalization
- **Severity**: 6-8
- **Detection**: Inter-annotator agreement (Kappa), label consistency checks
- **Mitigation**: Multiple annotators, expert review, noise-robust algorithms

#### 3.3 Outdated Data
- **Description**: Training data no longer reflects current reality
- **Causes**: Long collection period, slow update cycles, static dataset
- **Impact**: Model drift, irrelevant predictions
- **Severity**: 6-7
- **Detection**: Temporal analysis, data age monitoring
- **Mitigation**: Continuous data refresh, retraining schedule, date features

#### 3.4 Unrepresentative Data
- **Description**: Training data doesn't match production distribution
- **Causes**: Convenience sampling, selection bias, geographical bias
- **Impact**: Poor generalization, unfair outcomes
- **Severity**: 7-8
- **Detection**: Population distribution comparison, PSI calculation
- **Mitigation**: Representative sampling, importance weighting, domain adaptation

### 4. Model Drift Risks

#### 4.1 Concept Drift
- **Description**: Relationship between features and target changes over time
- **Causes**: Market changes, user behavior evolution, external events
- **Impact**: Performance degradation, wrong predictions
- **Example**: Credit risk model after economic crisis
- **Severity**: 7-9 (can be sudden and severe)
- **Detection**: Performance monitoring over time, residual analysis
- **Mitigation**: Continuous retraining, ensemble with recent data, adaptive models

#### 4.2 Covariate Drift (Feature Drift)
- **Description**: Input feature distribution changes
- **Causes**: Demographic shifts, seasonal patterns, market changes
- **Impact**: Predictions become unreliable
- **Severity**: 6-8
- **Detection**: PSI (Population Stability Index), KS-test
- **Mitigation**: Feature monitoring, retraining triggers, robust features

#### 4.3 Label Drift
- **Description**: Target variable distribution changes
- **Causes**: Business process changes, regulatory changes, market shifts
- **Impact**: Calibration issues, threshold invalidation
- **Severity**: 6-7
- **Detection**: Target distribution monitoring, rate tracking
- **Mitigation**: Regular recalibration, threshold updates, business rules

#### 4.4 Prediction Drift
- **Description**: Model output distribution changes without clear cause
- **Causes**: Interaction of concept and covariate drift, feedback loops
- **Impact**: Unexpected behavior, user confusion
- **Severity**: 7-8
- **Detection**: Output distribution monitoring, drift detection algorithms
- **Mitigation**: Root cause analysis, model refresh, A/B testing

### 5. Adversarial & Security Risks

#### 5.1 Evasion Attacks
- **Description**: Malicious inputs designed to fool the model
- **Causes**: Adversarial examples, input manipulation
- **Impact**: Wrong predictions, security breaches
- **Example**: Adding noise to image to bypass face recognition
- **Severity**: 7-9 (especially in security applications)
- **Detection**: Adversarial detection algorithms, anomaly detection
- **Mitigation**: Adversarial training, input validation, ensemble defenses

#### 5.2 Poisoning Attacks
- **Description**: Malicious data injected into training set
- **Causes**: Compromised data sources, insider threats
- **Impact**: Backdoored model, systematic failures
- **Severity**: 8-10 (can be subtle and persistent)
- **Detection**: Data provenance tracking, outlier detection, integrity checks
- **Mitigation**: Data validation, trusted sources only, anomaly filtering

#### 5.3 Model Extraction
- **Description**: Attacker recreates model through queries
- **Causes**: API access, prediction endpoint exposure
- **Impact**: IP theft, enables other attacks
- **Severity**: 6-8 (depending on model value)
- **Detection**: Query pattern monitoring, rate limiting
- **Mitigation**: Query limits, output rounding, differential privacy

#### 5.4 Membership Inference
- **Description**: Attacker determines if specific data was in training set
- **Causes**: Model memorization, overfitting
- **Impact**: Privacy violation, GDPR breach
- **Severity**: 7-9 (privacy risk)
- **Detection**: Membership inference testing, confidence analysis
- **Mitigation**: Differential privacy, regularization, data minimization

#### 5.5 Model Inversion
- **Description**: Attacker reconstructs training data from model
- **Causes**: Model overfitting, insufficient privacy protection
- **Impact**: Severe privacy breach, data leakage
- **Severity**: 9-10
- **Detection**: Privacy audits, reconstruction attacks testing
- **Mitigation**: Differential privacy, federated learning, output perturbation

### 6. Transparency & Explainability Risks

#### 6.1 Black Box Models
- **Description**: Model decisions not interpretable
- **Causes**: Complex architectures (deep learning, ensembles)
- **Impact**: Lack of trust, regulatory non-compliance, debugging difficulties
- **Severity**: 6-8 (higher for High-Risk AI)
- **Detection**: Model complexity metrics, explainability testing
- **Mitigation**: Simpler models, post-hoc explanations (SHAP, LIME), inherently interpretable models

#### 6.2 Misleading Explanations
- **Description**: Explanations don't reflect actual model logic
- **Causes**: Approximation errors in SHAP/LIME, cherry-picked examples
- **Impact**: False confidence, wrong decisions based on explanations
- **Severity**: 7-8
- **Detection**: Explanation fidelity testing, counterfactual analysis
- **Mitigation**: Multiple explanation methods, sanity checks, domain expert review

#### 6.3 Insufficient Documentation
- **Description**: Technical documentation incomplete or outdated
- **Causes**: Time pressure, documentation neglect, knowledge loss
- **Impact**: Audit failures, maintenance difficulties, compliance risk
- **Severity**: 6-7 (Art. 11 EU AI Act requirement)
- **Detection**: Documentation audits, completeness checklists
- **Mitigation**: Documentation templates, automated documentation, review process

### 7. Human Oversight Risks

#### 7.1 Automation Bias
- **Description**: Humans over-trust AI recommendations
- **Causes**: Perceived AI superiority, cognitive laziness, workload pressure
- **Impact**: Uncritical acceptance of errors, accountability issues
- **Severity**: 7-9 (undermines human oversight)
- **Detection**: Human override rate monitoring, decision audits
- **Mitigation**: Training, confidence displays, mandatory review for low confidence

#### 7.2 Deskilling
- **Description**: Humans lose ability to make decisions without AI
- **Causes**: Over-reliance on AI, lack of practice
- **Impact**: Inability to handle AI failures, degraded judgment
- **Severity**: 6-8 (long-term organizational risk)
- **Detection**: Skill assessments, error rates when AI unavailable
- **Mitigation**: Regular training, manual decision practice, rotation

#### 7.3 Alert Fatigue
- **Description**: Too many alerts lead to ignoring warnings
- **Causes**: Low threshold settings, high false positive rate
- **Impact**: Missing critical alerts, incidents not addressed
- **Severity**: 7-8
- **Detection**: Alert acknowledgment rates, response time trends
- **Mitigation**: Threshold tuning, alert prioritization, escalation automation

#### 7.4 Insufficient Human Oversight
- **Description**: No meaningful human review of AI decisions
- **Causes**: Fully automated processes, insufficient resources
- **Impact**: Regulatory violation (Art. 14 AI Act), uncaught errors
- **Severity**: 8-9 (compliance risk)
- **Detection**: Review rate monitoring, audit checks
- **Mitigation**: Mandatory review workflows, sampling strategies, Human-in-the-Loop

### 8. System Integration Risks

#### 8.1 API Failures
- **Description**: Model serving API unavailable or slow
- **Causes**: Infrastructure issues, overload, network problems
- **Impact**: Business process disruption, user frustration
- **Severity**: 6-8 (depending on criticality)
- **Detection**: API monitoring, uptime tracking, latency alerts
- **Mitigation**: Redundancy, caching, graceful degradation, SLA enforcement

#### 8.2 Version Mismatches
- **Description**: Model and preprocessing pipeline out of sync
- **Causes**: Deployment errors, version control issues
- **Impact**: Incorrect predictions, silent failures
- **Severity**: 7-9 (hard to detect)
- **Detection**: Version tracking, end-to-end testing, checksum validation
- **Mitigation**: Atomic deployments, versioning standards, CI/CD pipelines

#### 8.3 Data Pipeline Failures
- **Description**: Feature generation fails or produces wrong values
- **Causes**: Upstream data issues, logic errors, infrastructure failures
- **Impact**: Model gets wrong inputs, garbage predictions
- **Severity**: 7-9
- **Detection**: Data validation, schema checks, distribution monitoring
- **Mitigation**: Data contracts, validation gates, fallback mechanisms

### 9. Regulatory & Compliance Risks

#### 9.1 GDPR Violations
- **Description**: AI system violates data protection regulations
- **Causes**: Insufficient privacy controls, lack of consent, data retention
- **Impact**: Fines (up to 4% revenue), reputational damage
- **Severity**: 8-10
- **Detection**: Privacy audits, DPIA, DPO reviews
- **Mitigation**: Privacy by design, data minimization, consent management

#### 9.2 AI Act Non-Compliance
- **Description**: Failure to meet EU AI Act requirements
- **Causes**: Insufficient QMS, missing documentation, no monitoring
- **Impact**: Fines (up to 35M€ or 7% revenue), market prohibition
- **Severity**: 9-10
- **Detection**: Compliance audits, gap assessments
- **Mitigation**: QMS implementation, documentation, continuous monitoring

#### 9.3 Sector-Specific Regulations
- **Description**: Violation of industry-specific rules (finance, healthcare)
- **Causes**: Regulatory complexity, changing requirements
- **Impact**: Sanctions, license revocation
- **Severity**: 8-9
- **Detection**: Regulatory monitoring, legal reviews
- **Mitigation**: Sector expertise, compliance programs, regular reviews

## Risk Assessment Matrix

**Severity Scale (1-10):**
1-3: Negligible  
4-6: Marginal  
7-8: Critical  
9-10: Catastrophic

**Occurrence Scale (1-10):**
1-2: Remote (<1%)  
3-4: Low (1-5%)  
5-6: Moderate (5-20%)  
7-8: High (20-50%)  
9-10: Very High (>50%)

**Detection Scale (1-10):**
1-2: Very High (always detected)  
3-4: High (usually detected)  
5-6: Moderate (sometimes)  
7-8: Low (rarely)  
9-10: Very Low (almost never)

**RPN = Severity × Occurrence × Detection**

**Priority:**
- RPN > 400: Critical (immediate action)
- RPN 200-400: High (action within 3 months)
- RPN 100-200: Medium (action within 6 months)
- RPN < 100: Low (monitor, accept)

## Usage in FMEA

For each AI system, review this catalog and identify applicable risks:

1. **Brainstorm Session**: Review catalog with cross-functional team
2. **Context Adaptation**: Adjust severity/occurrence for specific use case
3. **Risk Prioritization**: Calculate RPN for each identified risk
4. **Mitigation Planning**: Address all RPN > 200 risks

## Version History

- v1.0 (Dec 2024): Initial release
- Planned: Quarterly updates based on emerging risks

## References

- EU AI Act (Regulation 2024/1689)
- NIST AI Risk Management Framework
- ISO/IEC 23894:2023 (AI Risk Management)
- GDPR (Regulation 2016/679)
