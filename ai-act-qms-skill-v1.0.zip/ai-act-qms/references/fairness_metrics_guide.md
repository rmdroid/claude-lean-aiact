# Fairness Metrics Guide
**Comprehensive guide to fairness and bias metrics for EU AI Act compliance**

Version: 1.0  
Last Updated: December 2024

## Purpose

This guide provides detailed explanations of fairness metrics for AI systems to support:
- Art. 9 bias risk assessment
- Fairness testing (Measure and Control phases)
- Mitigation strategy selection
- Post-market bias monitoring

## Fairness Concepts

### Group Fairness vs. Individual Fairness

**Group Fairness:**
- Compares outcomes across demographic groups
- Example: Approval rates similar for Male vs. Female
- Most common in practice, required by many regulations

**Individual Fairness:**
- Similar individuals get similar outcomes
- Harder to operationalize
- "Fairness through awareness" principle

### Protected Attributes (Sensitive Features)

Common protected attributes under EU law:
- Gender
- Racial or ethnic origin
- Religion or belief
- Disability
- Age
- Sexual orientation
- Nationality

**Note:** Art. 9 GDPR restricts processing of sensitive data!  
→ Legal basis required (e.g., explicit consent, legal obligation)  
→ Coordinate with Data Protection Officer

### Privileged vs. Unprivileged Groups

**Privileged Group:** Historically favored group (e.g., Male, White, Young)  
**Unprivileged Group:** Historically disadvantaged group (e.g., Female, Black, Senior)

**Important:** Privilege is context-dependent!  
Example: "Senior" may be privileged in some contexts (experience) but unprivileged in others (hiring)

## Core Fairness Metrics

### 1. Demographic Parity (Statistical Parity)

**Definition:**  
Positive prediction rates should be equal across groups.

**Mathematical:**
```
P(Ŷ = 1 | A = privileged) = P(Ŷ = 1 | A = unprivileged)
```

**Measurement:**
```
Demographic Parity Difference = |P(Ŷ=1|A=priv) - P(Ŷ=1|A=unpriv)|
```

**Interpretation:**
- Difference = 0: Perfect parity
- Difference < 0.05: Acceptable (5% threshold)
- Difference > 0.10: Significant bias

**Example:**
```
Male applicants: 60% approved
Female applicants: 45% approved
→ Difference = 0.15 (15%) ❌ Bias detected
```

**Pros:**
- Simple to understand and calculate
- Commonly used in regulation (US employment law)
- Easy to monitor in production

**Cons:**
- Ignores base rates (what if groups differ legitimately?)
- Can conflict with accuracy (fairness-accuracy tradeoff)
- May violate Equal Opportunity (next metric)

**When to Use:**
- Regulatory compliance (employment, lending)
- Marketing/advertising fairness
- Resource allocation decisions

**Python Implementation:**
```python
def demographic_parity_difference(y_pred, sensitive_attr, privileged_group):
    priv_rate = y_pred[sensitive_attr == privileged_group].mean()
    unpriv_rate = y_pred[sensitive_attr != privileged_group].mean()
    return abs(priv_rate - unpriv_rate)
```

---

### 2. Disparate Impact Ratio (Four-Fifths Rule)

**Definition:**  
Ratio of positive prediction rates between groups.

**Mathematical:**
```
Disparate Impact = P(Ŷ=1|A=unpriv) / P(Ŷ=1|A=priv)
```

**Interpretation:**
- Ratio = 1.0: Perfect parity
- Ratio ≥ 0.80: Acceptable (80% rule from US EEOC)
- Ratio < 0.80: Adverse impact (legal risk)

**Example:**
```
Male: 60% approved
Female: 45% approved
→ Ratio = 0.45 / 0.60 = 0.75 ❌ Below 80% threshold
```

**Pros:**
- Well-established in US employment law
- Clear legal threshold (0.80)
- Intuitive ratio interpretation

**Cons:**
- Arbitrary threshold (why 80%?)
- Less sensitive to small differences than DPD
- Can be misleading with small sample sizes

**When to Use:**
- HR/Recruitment systems
- Credit scoring
- Legal compliance documentation

**Python Implementation:**
```python
def disparate_impact_ratio(y_pred, sensitive_attr, privileged_group):
    priv_rate = y_pred[sensitive_attr == privileged_group].mean()
    unpriv_rate = y_pred[sensitive_attr != privileged_group].mean()
    return unpriv_rate / priv_rate if priv_rate > 0 else 0
```

---

### 3. Equalized Odds (Equal Opportunity)

**Definition:**  
True Positive Rates (TPR) and False Positive Rates (FPR) should be equal across groups.

**Mathematical:**
```
P(Ŷ=1|Y=1, A=priv) = P(Ŷ=1|Y=1, A=unpriv)  [TPR equality]
P(Ŷ=1|Y=0, A=priv) = P(Ŷ=1|Y=0, A=unpriv)  [FPR equality]
```

**Measurement:**
```
TPR Difference = |TPR_priv - TPR_unpriv|
FPR Difference = |FPR_priv - FPR_unpriv|
Max Difference = max(TPR_diff, FPR_diff)
```

**Interpretation:**
- Max Diff = 0: Perfect equalized odds
- Max Diff < 0.05: Acceptable
- Max Diff > 0.10: Significant bias

**Example:**
```
            True Positives (Actual=1)    False Positives (Actual=0)
Male:       TPR = 0.92                   FPR = 0.08
Female:     TPR = 0.85                   FPR = 0.12

TPR Diff = 0.07 ⚠️
FPR Diff = 0.04 ✅
Max Diff = 0.07 (moderate bias)
```

**Pros:**
- Considers ground truth (actual outcomes)
- More nuanced than demographic parity
- Captures both errors (false positives and negatives)

**Cons:**
- Requires access to true labels (not always available)
- More complex to explain
- Harder to achieve (two constraints instead of one)

**When to Use:**
- Predictive policing
- Medical diagnosis
- Fraud detection
- Any high-stakes decision where errors matter differently

**Python Implementation:**
```python
def equalized_odds_difference(y_true, y_pred, sensitive_attr, privileged_group):
    # True Positive Rate
    priv_mask_pos = (sensitive_attr == privileged_group) & (y_true == 1)
    unpriv_mask_pos = (sensitive_attr != privileged_group) & (y_true == 1)
    tpr_priv = y_pred[priv_mask_pos].mean() if priv_mask_pos.sum() > 0 else 0
    tpr_unpriv = y_pred[unpriv_mask_pos].mean() if unpriv_mask_pos.sum() > 0 else 0
    
    # False Positive Rate
    priv_mask_neg = (sensitive_attr == privileged_group) & (y_true == 0)
    unpriv_mask_neg = (sensitive_attr != privileged_group) & (y_true == 0)
    fpr_priv = y_pred[priv_mask_neg].mean() if priv_mask_neg.sum() > 0 else 0
    fpr_unpriv = y_pred[unpriv_mask_neg].mean() if unpriv_mask_neg.sum() > 0 else 0
    
    return max(abs(tpr_priv - tpr_unpriv), abs(fpr_priv - fpr_unpriv))
```

---

### 4. Equal Opportunity (Simplified Equalized Odds)

**Definition:**  
True Positive Rates should be equal across groups (only TPR, not FPR).

**Mathematical:**
```
P(Ŷ=1|Y=1, A=priv) = P(Ŷ=1|Y=1, A=unpriv)
```

**Measurement:**
```
Equal Opportunity Difference = |TPR_priv - TPR_unpriv|
```

**Example:**
```
Male: TPR = 0.92 (92% of qualified males get opportunity)
Female: TPR = 0.85 (85% of qualified females get opportunity)
→ Difference = 0.07 ⚠️
```

**Pros:**
- Simpler than full equalized odds
- Focuses on "opportunity" for qualified individuals
- Widely cited in fairness literature

**Cons:**
- Ignores false positive disparities
- May allow unfair burden on unprivileged group (higher FPR)

**When to Use:**
- Hiring decisions (focus on qualified candidates)
- University admissions
- Loan approvals (focus on creditworthy applicants)

---

### 5. Predictive Parity (Outcome Parity)

**Definition:**  
Positive Predictive Value (Precision) should be equal across groups.

**Mathematical:**
```
P(Y=1|Ŷ=1, A=priv) = P(Y=1|Ŷ=1, A=unpriv)
```

**Measurement:**
```
PPV Difference = |PPV_priv - PPV_unpriv|

where PPV = TP / (TP + FP)
```

**Example:**
```
Male: Of those approved, 88% were actually qualified (PPV=0.88)
Female: Of those approved, 82% were actually qualified (PPV=0.82)
→ Difference = 0.06 ⚠️
```

**Pros:**
- User-centric (what does positive prediction mean?)
- Important for trust and calibration
- Relevant when positive outcome is desired

**Cons:**
- Can't be achieved simultaneously with Equal Opportunity (impossibility theorem)
- Requires ground truth labels
- Sensitive to base rates

**When to Use:**
- Medical diagnosis (positive diagnosis accuracy)
- Product recommendations (relevance to user)
- Search ranking (precision of top results)

---

### 6. Calibration

**Definition:**  
Predicted probabilities match actual outcomes across groups.

**Mathematical:**
```
For each predicted probability p:
P(Y=1|Ŷ=p, A=priv) = P(Y=1|Ŷ=p, A=unpriv)
```

**Measurement:**
Calibration curve: Plot predicted probability vs. actual frequency  
→ Should be same line for all groups (diagonal = perfect calibration)

**Example:**
```
When model predicts 70% probability:
Male: Actually 70% qualified ✅
Female: Actually 55% qualified ❌ Model overconfident for females
```

**Pros:**
- Important for probability-based decisions
- Relates to trust and reliability
- Can use probabilistic predictions (not just binary)

**Cons:**
- Requires access to probabilities (not just classes)
- Harder to compute (bucketing required)
- Can conflict with other fairness metrics

**When to Use:**
- Risk assessment (need accurate probabilities)
- Recommender systems (confidence scores)
- Any decision that uses predicted probabilities

**Python Implementation:**
```python
from sklearn.calibration import calibration_curve

def check_calibration_fairness(y_true, y_prob, sensitive_attr, groups):
    for group in groups:
        mask = sensitive_attr == group
        prob_true, prob_pred = calibration_curve(
            y_true[mask], y_prob[mask], n_bins=10
        )
        # Plot or analyze prob_true vs prob_pred
```

---

## Impossibility Theorems

**Important:** You CANNOT achieve all fairness metrics simultaneously!

### Chouldechova's Theorem (2017)
Cannot have:
1. Equal False Positive Rates (FPR)
2. Equal False Negative Rates (FNR)  
3. Predictive Parity (PPV equality)

...unless base rates are equal across groups.

### Kleinberg et al. Theorem (2016)
Cannot have:
1. Calibration
2. Balance (Equalized Odds)
3. Equal base rates

### Implication
**You must choose which fairness metric to optimize!**  
→ Business decision based on use case  
→ Document rationale in QMS

## Metric Selection Guide

| Use Case | Primary Metric | Secondary Metric | Rationale |
|----------|----------------|------------------|-----------|
| **Hiring** | Equal Opportunity | Disparate Impact | Focus on qualified candidates getting hired |
| **Credit Scoring** | Equalized Odds | Predictive Parity | Both false positives and negatives costly |
| **Medical Diagnosis** | Equalized Odds | Calibration | Errors in both directions critical |
| **Ad Targeting** | Demographic Parity | - | Equal exposure to opportunities |
| **University Admissions** | Equal Opportunity | - | Qualified students get admitted |
| **Risk Assessment** | Calibration | Equalized Odds | Need accurate probabilities |
| **Content Moderation** | Equalized Odds | - | Both false positives (censorship) and negatives (harm) matter |

## Intersectional Fairness

**Intersectionality:** Fairness for combinations of attributes  
Example: Not just Gender OR Race, but Gender × Race

**Why Important:**
- Single-attribute fairness can hide subgroup disparities
- Black Women may face different bias than Black Men or White Women

**How to Measure:**
```python
# Create intersectional groups
data['intersectional'] = data['gender'] + '_' + data['race']

# Compute metrics for each combination
for group in ['Male_White', 'Male_Black', 'Female_White', 'Female_Black']:
    metrics[group] = calculate_fairness_metrics(
        predictions[data['intersectional'] == group]
    )
```

**Challenge:** Small sample sizes for rare combinations  
→ May need to accept higher variance or collect more data

## Threshold Optimization for Fairness

**Problem:** Single threshold may be unfair  
**Solution:** Optimize different thresholds per group

**Example:**
```
Original threshold = 0.5 (same for all)
→ Male approval rate: 60%
→ Female approval rate: 45%

Optimized thresholds:
→ Male: 0.52
→ Female: 0.48
→ Now both ~52% approval rate ✅
```

**Pros:**
- Can achieve demographic parity post-hoc
- No retraining needed

**Cons:**
- Different treatment (transparency issue)
- May violate "individual fairness"
- Legal implications (explicit use of protected attribute)

**Tool:** `fairlearn.postprocessing.ThresholdOptimizer`

## Fairness Constraints in Training

**In-Processing Methods:** Add fairness as objective during training

**Example (Fairlearn):**
```python
from fairlearn.reductions import ExponentiatedGradient, DemographicParity

constraint = DemographicParity()
mitigator = ExponentiatedGradient(estimator=model, constraints=constraint)
mitigator.fit(X, y, sensitive_features=A)
```

**Available Constraints:**
- Demographic Parity
- Equalized Odds
- Equal Opportunity
- Bounded Group Loss

**Tradeoff:** Fairness constraints typically reduce accuracy  
→ Quantify: "How much accuracy loss for fairness gain?"  
→ Document in QMS

## Monitoring Fairness Over Time

**Post-Market Monitoring (Art. 72):**

```
Weekly Check:
- Demographic Parity Difference
- Disparate Impact Ratio

Monthly Review:
- Equalized Odds
- Predictive Parity
- Subgroup Performance

Quarterly Audit:
- Intersectional Fairness
- Calibration
- Full Fairness Report
```

**Thresholds:**
```
Demographic Parity Difference:
- Target: < 0.03
- Warning: 0.03 - 0.05
- Alert: 0.05 - 0.10
- Critical: > 0.10

Disparate Impact:
- Target: > 0.85
- Warning: 0.80 - 0.85
- Alert: 0.75 - 0.80
- Critical: < 0.75
```

## Reporting Fairness

**Stakeholder Communication:**

For **Technical Audience:**
```
Fairness Metrics:
- Demographic Parity Diff: 0.04 (Warning)
- Equalized Odds Diff: 0.06 (Alert)
- Disparate Impact: 0.78 (Critical)
```

For **Non-Technical Audience:**
```
Our hiring AI shows a gender fairness gap:
- Male candidates: 60% recommended
- Female candidates: 47% recommended

This 13% gap exceeds our 5% fairness threshold.

Action: We're implementing fairness constraints to reduce gap to <5%.
Timeline: Q1 2025
```

For **Regulators:**
```
EU AI Act Art. 9 Bias Assessment:

Protected Attribute: Gender
Metric: Disparate Impact Ratio
Value: 0.78
Threshold: 0.80 (80% Rule)
Status: Below threshold (adverse impact detected)

Mitigation Implemented:
- Fairness constraints (Demographic Parity)
- Resampling training data
- Monthly monitoring activated

Residual Risk: Low (post-mitigation DI = 0.84)
```

## Tools & Libraries

**Python Libraries:**
- `fairlearn`: Microsoft's fairness toolkit
- `aif360`: IBM's AI Fairness 360
- `folktables`: Benchmark fairness datasets

**Example Usage:**
```python
from fairlearn.metrics import (
    demographic_parity_difference,
    equalized_odds_difference,
    MetricFrame
)

# Calculate all metrics at once
mf = MetricFrame(
    metrics={
        'accuracy': accuracy_score,
        'dem_parity': demographic_parity_difference,
        'eq_odds': equalized_odds_difference
    },
    y_true=y_test,
    y_pred=y_pred,
    sensitive_features=A_test
)

print(mf.by_group)  # Metrics per group
print(mf.overall)   # Overall metrics
print(mf.difference())  # Max difference across groups
```

## Legal & Regulatory Context

**EU AI Act:**
- Art. 9: Risk management must address bias
- Art. 10(2)(f): Training data "free from errors and complete"
- Art. 10(2)(g): "Appropriate statistical properties, including, where applicable, as regards the persons or groups of persons in relation to whom the high-risk AI system is intended to be used"
- Art. 72: Post-market monitoring including "performance across groups"

**GDPR:**
- Art. 22: Right not to be subject to automated decision-making
- Art. 9: Special category data (sensitive attributes)

**US:**
- EEOC 80% Rule (Disparate Impact)
- Fair Credit Reporting Act
- Equal Credit Opportunity Act

## References

- Hardt et al. (2016): "Equality of Opportunity in Supervised Learning"
- Chouldechova (2017): "Fair prediction with disparate impact"
- Kleinberg et al. (2016): "Inherent Trade-Offs in the Fair Determination of Risk Scores"
- Barocas et al. (2019): "Fairness and Machine Learning" (fairmlbook.org)
- EU AI Act (Regulation 2024/1689)
