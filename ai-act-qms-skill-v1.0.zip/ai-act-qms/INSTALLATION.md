# Installation & Nutzung: EU AI Act Compliance QMS Skill

## 📦 Skill-Installation

### Schritt 1: Download

Du hast den kompletten Skill bereits heruntergeladen. Der Ordner `ai-act-qms` enthält:

```
ai-act-qms/
├── SKILL.md                 # Haupt-Skill-Datei
├── README.md                # Dokumentation
├── INSTALLATION.md          # Diese Datei
├── references/              # DMAIC-Phasen Dokumentation
│   ├── aiact_define.md
│   ├── aiact_measure.md
│   ├── aiact_analyze.md
│   ├── aiact_improve.md
│   ├── aiact_control.md
│   ├── ai_risk_catalog.md
│   └── fairness_metrics_guide.md
├── scripts/                 # Python Scripts
│   ├── bias_detection.py
│   ├── drift_detection.py
│   ├── ai_control_charts.py
│   └── ai_fmea_calculator.py
└── assets/                  # Templates
    ├── excel/               # Excel Templates
    │   ├── ai_system_charter.xlsx
    │   ├── ai_fmea.xlsx
    │   ├── risk_register.xlsx
    │   ├── monitoring_plan.xlsx
    │   └── evidence_log.xlsx
    └── pptx/                # PowerPoint Templates
        ├── qms_documentation.pptx
        ├── compliance_tollgate_review.pptx
        └── audit_readiness_presentation.pptx
```

### Schritt 2: Skill in Claude hochladen

1. **Öffne Claude.ai** in deinem Browser
2. **Erstelle oder öffne ein Project** wo du den Skill nutzen möchtest
3. **Klicke auf "Add Content" → "Upload files"**
4. **Wähle den gesamten `ai-act-qms` Ordner** oder die einzelne `SKILL.md` Datei
5. **Alternativ:** Nutze das Project Knowledge Feature:
   - Gehe zu Project Settings
   - "Add Custom Instructions"
   - Füge die `SKILL.md` Datei hinzu

### Schritt 3: Python Scripts nutzen

Die Python Scripts können lokal ausgeführt werden oder in Claude's Computer Use Feature.

**Lokale Nutzung:**

```bash
# Installiere Dependencies
pip install numpy pandas scipy matplotlib seaborn openpyxl python-pptx

# Bias Detection ausführen
python scripts/bias_detection.py

# Drift Detection ausführen
python scripts/drift_detection.py

# Control Charts generieren
python scripts/ai_control_charts.py

# FMEA Calculator ausführen
python scripts/ai_fmea_calculator.py
```

**In Claude:**

```
Bitte führe das bias_detection.py Script aus und analysiere meine Daten
```

Claude hat Zugriff auf die Scripts im Skill-Verzeichnis.

## 🚀 Verwendung

### Quick Start

```
/start aiact
```

Dies startet das AI Act Compliance Assessment. Claude führt dich durch:
1. Risikoklassifizierung
2. Gap-Analyse
3. Roadmap-Entwicklung

### Trigger-Befehle

```
/start aiact     # Vollständiges Assessment starten
/aiact risk      # Risikomanagement (Art. 9)
/aiact qms       # QMS Dokumentation (Art. 17)
/aiact monitor   # Post-Market Monitoring (Art. 72)
```

### Typischer Workflow

#### 1. Assessment & Define Phase

```
User: /start aiact

Claude: Startet Assessment
        → Klassifiziert AI-System (High-Risk?)
        → Identifiziert Compliance Gaps
        → Erstellt Project Charter
```

#### 2. Measure Phase

```
User: Wir haben Baseline Performance Daten. Bitte analysiere auf Bias.

Claude: → Nutzt bias_detection.py
        → Berechnet Demographic Parity, Disparate Impact
        → Erstellt Bias Assessment Report
```

#### 3. Analyze Phase

```
User: Erstelle eine AI-FMEA für unser Recruiting System

Claude: → Nutzt AI Risk Catalog
        → Führt durch FMEA Workshop
        → Berechnet RPNs mit ai_fmea_calculator.py
        → Erstellt Risk Register
```

#### 4. Improve Phase

```
User: Welche Mitigation Strategies gibt es für Gender Bias?

Claude: → Präsentiert Optionen (Resampling, Fairness Constraints, etc.)
        → Erklärt Pros/Cons
        → Hilft bei QMS Dokumentation
        → Erstellt SOPs
```

#### 5. Control Phase

```
User: Erstelle einen Monitoring Plan für Art. 72 Compliance

Claude: → Nutzt monitoring_plan.xlsx Template
        → Definiert Schwellwerte
        → Erstellt Eskalationspfade
        → Setup Control Charts (ai_control_charts.py)
```

## 📊 Templates nutzen

### Excel Templates

Die Excel Templates sind fertig ausgefüllt mit Beispieldaten:

```
assets/excel/ai_system_charter.xlsx    # Für Define Phase
assets/excel/ai_fmea.xlsx               # Für Analyze Phase
assets/excel/risk_register.xlsx         # Für Analyze Phase
assets/excel/monitoring_plan.xlsx       # Für Control Phase
assets/excel/evidence_log.xlsx          # Durchgängig
```

**Verwendung:**
1. Template öffnen
2. Beispieldaten durch eigene Daten ersetzen
3. Formeln bleiben erhalten (z.B. RPN Berechnung)

### PowerPoint Templates

```
assets/pptx/qms_documentation.pptx              # QMS Übersicht
assets/pptx/compliance_tollgate_review.pptx     # Tollgate Reviews
assets/pptx/audit_readiness_presentation.pptx   # Audit Prep
```

**Verwendung:**
1. Präsentation öffnen
2. Platzhalter `[...]` durch eigene Inhalte ersetzen
3. Anpassen an Corporate Design

## 🔧 Konfiguration

### Python Dependencies

Alle Scripts benötigen:

```bash
pip install numpy pandas scipy matplotlib seaborn openpyxl python-pptx
```

**Oder mit requirements.txt:**

```bash
# Erstelle requirements.txt
cat > requirements.txt << EOF
numpy>=1.20.0
pandas>=1.3.0
scipy>=1.7.0
matplotlib>=3.4.0
seaborn>=0.11.0
openpyxl>=3.0.9
python-pptx>=0.6.21
EOF

# Installiere
pip install -r requirements.txt
```

### Claude Project Setup

**Empfohlene Project-Einstellungen:**

1. **Project Name:** "AI Act Compliance - [AI System Name]"
2. **Custom Instructions:** Füge hinzu:
   ```
   Dieser Project nutzt den ai-act-qms Skill für EU AI Act Compliance.
   Nutze DMAIC-Methodik für systematische Compliance.
   Priorität: Auditfähigkeit und Dokumentation.
   ```

3. **Knowledge Base:** Upload relevante Dokumente:
   - AI System Dokumentation
   - Training Data Beschreibung
   - Business Requirements
   - Existing Risk Assessments

## 🎯 Best Practices

### 1. Strukturiertes Vorgehen

Folge immer dem DMAIC-Prozess:
- **Define** → Scope klar definieren
- **Measure** → Baseline etablieren
- **Analyze** → Risiken systematisch bewerten
- **Improve** → Mitigation implementieren
- **Control** → Monitoring aufsetzen

### 2. Dokumentation from Day 1

Nutze das Evidence Log ab dem ersten Tag:
- Jede wichtige Entscheidung dokumentieren
- Meeting Minutes hochladen
- Reports speichern
- Mapping zu AI Act Artikeln

### 3. Iterativ arbeiten

Nicht alles auf einmal:
- Start mit einem High-Risk System (Pilot)
- Quick Wins identifizieren
- Learnings in nächstes System übertragen

### 4. Team einbinden

Cross-funktionale Workshops:
- AI-FMEA mit ML Engineers + Legal + Compliance
- Governance Operating Model mit Management
- SOP Training mit gesamtem Team

### 5. Tools nutzen

Automatisiere wo möglich:
- Python Scripts für regelmäßige Checks
- Dashboards für Monitoring
- Alerts für Threshold Violations

## 📚 Weitere Ressourcen

### In diesem Skill enthalten

- **references/ai_risk_catalog.md**: Kompletter Katalog AI-spezifischer Risiken
- **references/fairness_metrics_guide.md**: Detaillierte Erklärung aller Fairness Metrics
- **references/aiact_*.md**: Schritt-für-Schritt Anleitungen pro DMAIC Phase

### External Links

- **EU AI Act:** https://eur-lex.europa.eu/eli/reg/2024/1689/oj
- **NIST AI RMF:** https://www.nist.gov/itl/ai-risk-management-framework
- **ISO 42001:** https://www.iso.org/standard/81230.html
- **Fairlearn Toolkit:** https://fairlearn.org/

## 🆘 Troubleshooting

### "Skill wird nicht erkannt"

**Problem:** Claude reagiert nicht auf `/start aiact`

**Lösung:**
1. Prüfe ob `SKILL.md` im Project hochgeladen ist
2. Alternativ: Sage "Nutze den ai-act-qms Skill" explizit
3. Verifiziere Skill ist in Project Knowledge

### "Python Scripts laufen nicht"

**Problem:** Import Errors oder Missing Dependencies

**Lösung:**
```bash
# Prüfe Python Version (>=3.8 erforderlich)
python --version

# Installiere alle Dependencies
pip install numpy pandas scipy matplotlib seaborn openpyxl python-pptx

# Teste Script einzeln
python -c "import pandas; print(pandas.__version__)"
```

### "Templates öffnen nicht"

**Problem:** Excel/PowerPoint Fehler

**Lösung:**
- Nutze Excel 2016 oder neuer (oder LibreOffice Calc)
- Nutze PowerPoint 2016 oder neuer (oder LibreOffice Impress)
- Alternativ: Google Sheets/Slides (Upload + Konvertierung)

### "Zu komplex, wo fange ich an?"

**Lösung:**
```
User: Ich habe ein Recruiting AI System. Wo fange ich an?

Claude: Startet einfaches Assessment
        → Quick Win Ansatz
        → Step-by-Step Guidance
```

## 🔄 Updates

### Skill aktualisieren

Wenn neue Versionen des Skills verfügbar sind:

1. Download neue Version
2. Backup alte Version (falls Anpassungen gemacht)
3. Ersetze `SKILL.md` und relevante Dateien
4. Überprüfe Kompatibilität mit deinen Daten

### Eigene Anpassungen

Du kannst den Skill anpassen:
- Ergänze eigene Risiken in `references/ai_risk_catalog.md`
- Passe Schwellwerte in Scripts an
- Erweitere Templates um firmenspezifische Felder

**Tipp:** Versioniere deine Anpassungen!

## 📧 Support

Bei Fragen oder Problemen:

1. **Prüfe README.md** für detaillierte Skill-Dokumentation
2. **Konsultiere Reference Docs** für Phase-spezifische Hilfe
3. **GitHub Issues** (wenn Skill auf GitHub gehostet)
4. **Claude direkt fragen:**
   ```
   Ich habe ein Problem mit [XYZ]. Wie löse ich das im Kontext des ai-act-qms Skills?
   ```

## ✅ Checkliste: Erfolgreiche Installation

- [ ] Skill-Ordner heruntergeladen
- [ ] `SKILL.md` in Claude Project hochgeladen
- [ ] Python Dependencies installiert (für lokale Nutzung)
- [ ] Test: `/start aiact` funktioniert
- [ ] Excel Templates öffnen sich
- [ ] PowerPoint Templates öffnen sich
- [ ] Python Scripts laufen lokal (optional)

Wenn alle Punkte abgehakt: **Ready to go!** 🚀

## 🎉 Next Steps

Jetzt bist du bereit! Starte mit:

```
/start aiact
```

Viel Erfolg bei der EU AI Act Compliance! 💪
